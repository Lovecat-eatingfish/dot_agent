package com.eq.sf.cache;

import java.util.HashMap;
import java.util.Map;

public class LFUCacheDemo {
    class Node {
        int key;
        int value;
        int freq;
        Node next;
        Node prev;

        public Node(int key, int value) {
            this.key = key;
            this.value = value;
            this.freq = 1;
        }

        public Node() {
            this(-1, -1);
        }
    }

    class DoubleFreqList {
        Node head;
        Node tail;
        int size;

        public DoubleFreqList() {
            this.head = new Node();
            this.tail = new Node();
            head.next = tail;
            tail.prev = head;
            this.size = 0;
        }

        public void addFirst(Node node) {
            node.next = head.next;
            head.next.prev = node;
            node.prev = head;
            head.next = node;
            size++;
        }

        public void remove(Node node) {
            node.prev.next = node.next;
            node.next.prev = node.prev;
            size--;
        }

        public Node removeLast() {
            if (size == 0) return null;
            Node last = tail.prev;
            remove(last);
            return last;
        }

        boolean isEmpty() {
            return size == 0;
        }
    }

    Map<Integer, DoubleFreqList> freqMap;
    Map<Integer, Node> cache;
    int minFreq;
    int capacity;

    public LFUCacheDemo(int capacity) {
        this.capacity = capacity;
        this.minFreq = 0;
        this.cache = new HashMap<>();
        this.freqMap = new HashMap<>();
    }

    public int get(int key) {
        if (capacity == 0) return -1;

        Node node = cache.get(key);
        if (node == null) return -1;

        updateFreq(node);
        return node.value;
    }

    public void put(int key, int value) {
        if (capacity == 0) return;

        Node node = cache.get(key);
        if (node != null) {
            node.value = value;
            updateFreq(node);
            return;
        }

        // 缓存已满，淘汰
        if (cache.size() == capacity) {
            DoubleFreqList minFreqList = freqMap.get(minFreq);
            if (minFreqList != null) {
                Node removed = minFreqList.removeLast();
                if (removed != null) {
                    cache.remove(removed.key);  // ✅ 从cache移除
                }
                if (minFreqList.isEmpty()) {
                    freqMap.remove(minFreq);
                }
            }
        }

        // 插入新节点
        Node newNode = new Node(key, value);
        cache.put(key, newNode);

        // ✅ 使用 computeIfAbsent
        freqMap.computeIfAbsent(1, k -> new DoubleFreqList())
                .addFirst(newNode);
        minFreq = 1;
    }

    public void remove(int key) {
        Node node = cache.get(key);
        if (node == null) return;

        int freq = node.freq;
        DoubleFreqList list = freqMap.get(freq);
        if (list != null) {
            list.remove(node);
            if (list.isEmpty()) {
                freqMap.remove(freq);
                if (minFreq == freq) {
                    // 找到下一个最小频率
                    minFreq = findNextMinFreq();
                }
            }
        }
        cache.remove(key);  // ✅ 从cache移除
    }

    // ✅ 辅助方法：找到下一个最小频率
    private int findNextMinFreq() {
        for (int f = 1; f <= cache.size(); f++) {
            if (freqMap.containsKey(f)) {
                return f;
            }
        }
        return 0;
    }

    private void updateFreq(Node node) {
        int oldFreq = node.freq;
        DoubleFreqList oldList = freqMap.get(oldFreq);
        if (oldList != null) {
            oldList.remove(node);
            if (oldList.isEmpty()) {
                freqMap.remove(oldFreq);
                if (minFreq == oldFreq) {
                    minFreq++;
                }
            }
        }

        node.freq++;
        // ✅ 使用 computeIfAbsent
        freqMap.computeIfAbsent(node.freq, k -> new DoubleFreqList())
                .addFirst(node);
    }
}