package com.eq.sf.graph;

import java.util.ArrayList;
import java.util.List;

public class Graph {
}
