package com.eq.sf.juc.solution;

public class PrintJOSync {
    public static void main(String[] args) throws InterruptedException {
        PrintJOSync printJO = new PrintJOSync(100);
        Thread o = new Thread(printJO::printO);
        Thread j = new Thread(printJO::printJ);

        o.start();
        j.start();


        o.join();
        j.join();
    }

    private int count = 1;
    private int max;
    private final Object lock = new Object();

    public PrintJOSync(int max) {
        this.max = max;
    }

    public void printJ() {
        while (count <= max) {
            synchronized (lock) {
                while (count <= max && count % 2 == 0) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }

                if (count <= max) {
                    System.out.println(count);
                    count++;
                    lock.notify();
                }
            }
        }
    }

    public void printO() {
        while (count <= max) {
            synchronized (lock) {
                while (count <= max && count % 2 == 1) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                if (count <= max) {
                    System.out.println(count);
                    count++;
                    lock.notify();
                }
            }
        }
    }
}
