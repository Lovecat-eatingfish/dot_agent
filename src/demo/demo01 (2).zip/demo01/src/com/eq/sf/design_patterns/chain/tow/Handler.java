package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

public abstract class Handler {
    private Handler nextHandler;

    public void setNextHandler(Handler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract boolean handle(Request request);


    public void doNext(Request request) {
        if (nextHandler != null) {
            nextHandler.handle(request);
        }
    }
}
