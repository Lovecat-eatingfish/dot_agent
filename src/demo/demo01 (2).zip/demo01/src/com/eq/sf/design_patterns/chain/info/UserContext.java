package com.eq.sf.design_patterns.chain.info;

/**
 * 用户登录上下文 - ThreadLocal存储
 * 用于在同一个线程中传递用户登录信息
 */
public class UserContext {
    
    private static final ThreadLocal<UserInfo> USER_HOLDER = new ThreadLocal<>();
    
    /**
     * 设置当前线程的用户信息
     */
    public static void setUser(UserInfo userInfo) {
        USER_HOLDER.set(userInfo);
    }
    
    /**
     * 获取当前线程的用户信息
     */
    public static UserInfo getUser() {
        return USER_HOLDER.get();
    }
    
    /**
     * 获取当前用户ID
     */
    public static Long getUserId() {
        UserInfo user = getUser();
        return user != null ? user.getUserId() : null;
    }
    
    /**
     * 获取当前用户名
     */
    public static String getUsername() {
        UserInfo user = getUser();
        return user != null ? user.getUsername() : null;
    }
    
    /**
     * 判断是否已登录
     */
    public static boolean isLogin() {
        return getUser() != null;
    }
    
    /**
     * 清除当前线程的用户信息（防止内存泄漏）
     */
    public static void clear() {
        USER_HOLDER.remove();
    }
}