package com.eq.sf.design_patterns.chain.one;

// 权限校验处理器
public class AuthHandler extends Handler {
    @Override
    public void handle(Request request) {
        if (!request.hasPermission()) {
            System.out.println("权限校验失败，拦截请求");
            return;
        }
        System.out.println("权限校验通过");
        doNext(request);


        System.out.println("权限校验处理器后置处理");
    }
}
