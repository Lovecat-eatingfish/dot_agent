package com.eq.sf.solution;

public class AgainSolution1 {

    public void heapSort(int[] arr) {
        buildHeap(arr);

        for (int i = arr.length - 1; i > 0; i--) {
            swap(arr, 0, i);
            down(arr, 0, i);
        }
    }

    private void buildHeap(int[] arr) {
        for (int i = (arr.length - 1) / 2; i >= 0; i--) {
            down(arr, i, arr.length);
        }
    }

    private void down(int[] arr, int index, int size) {
        while (true) {
            int maxIndex = index;
            int left = index * 2 + 1;
            int right = index * 2 + 2;
            if (left < size && arr[left] > arr[maxIndex]) {
                maxIndex = left;
            }
            if (right < size && arr[right] > arr[maxIndex]) {
                maxIndex = right;
            }

            if (index == maxIndex) {
                break;
            }
            swap(arr, index, maxIndex);
            index = maxIndex;
        }
    }

    private void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
