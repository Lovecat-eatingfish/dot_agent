package com.eq.sf.design_patterns.chain.tow;


import com.eq.sf.design_patterns.chain.info.UserContext;
import com.eq.sf.design_patterns.chain.info.UserInfo;
import com.eq.sf.design_patterns.chain.one.Request;

import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {
        // 1. 创建处理器
        LoginHandler loginHandler = new LoginHandler();
        AuthHandler authHandler = new AuthHandler();
        RateLimitHandler rateLimitHandler = new RateLimitHandler();
        BusinessHandler businessHandler = new BusinessHandler();

        // 2. 组装链（顺序很重要）
        loginHandler.setNextHandler(authHandler);
        authHandler.setNextHandler(rateLimitHandler);
        rateLimitHandler.setNextHandler(businessHandler);

        HandlerChain chain = new HandlerChain();
        chain.addHandler(loginHandler);
        chain.addHandler(authHandler);
        chain.addHandler(rateLimitHandler);
        chain.addHandler(businessHandler);

        // 模拟用户登录，设置用户信息
        UserInfo user = new UserInfo(1001L, "test_user");
        user.setNickname("测试用户");
        user.setEmail("test@example.com");
        user.setLoginTime(LocalDateTime.now());
        user.setUserType(1);

        UserContext.setUser(user);
        // 3. 创建请求

        Request request = new Request();
        request.setLogin(true);
        request.setPermission(true);
        request.setData("查询用户信息");
        try {
            chain.handle(request);
        } catch (Exception e) {
            System.out.println("链条执行出现错误");
        } finally {
            UserContext.clear();
        }

    }
}
