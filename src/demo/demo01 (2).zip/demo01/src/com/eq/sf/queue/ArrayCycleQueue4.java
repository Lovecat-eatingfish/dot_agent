package com.eq.sf.queue;

import java.util.Iterator;

public class ArrayCycleQueue4<E> implements Queue<E>, Iterable<E> {
    public int capacity;
    public E[] arr;
    public int tail = 0;
    public int head = 0;
    public int mask;

    public ArrayCycleQueue4(int capacity) {
        // 找到大于等于 capacity 的最小 2 的幂
        int realCapacity = 1;
        while (realCapacity < capacity) {
            realCapacity <<= 1;  // 左移一位，相当于乘以2
        }
        this.capacity = realCapacity;
        mask = realCapacity - 1;
        this.arr = (E[]) new Object[realCapacity];
        tail = 0;
        head = 0;
    }

    @Override
    public boolean offer(E value) {
        if (isFull()) {
            System.out.println("队列已满");
            return false;
        }
        arr[tail & mask] = value;  // ✅ 位运算代替取模

        tail++;
        return true;
    }

    @Override
    public E poll() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        E poll = arr[head & mask];  // ✅ 位运算代替取模

        head++;
        return poll;
    }

    @Override
    public E peek() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        int index = head % capacity;
        return arr[index];
    }

    @Override
    public boolean isEmpty() {
        return tail == head;
    }

    @Override
    public boolean isFull() {
        return tail - head == capacity;
    }

    @Override
    public int size() {
        return tail - head;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int p = head;

            @Override
            public boolean hasNext() {
                return p < tail;
            }

            @Override
            public E next() {
                E value = arr[p & mask];  // ✅ 位运算代替取模
                p++;
                return value;
            }
        };
    }
}
