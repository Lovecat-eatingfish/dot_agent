package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

// 限流处理器
public class RateLimitHandler extends Handler {
    @Override
    public boolean handle(Request request) {
        if (isRateLimited()) {
            System.out.println("请求被限流，拦截");
            return false;
        }
        System.out.println("限流校验通过");
        return true;
    }

    private boolean isRateLimited() {
        // 模拟限流逻辑
        return false;
    }
}
