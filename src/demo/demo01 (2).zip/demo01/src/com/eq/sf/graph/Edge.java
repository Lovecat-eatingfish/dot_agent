package com.eq.sf.graph;

public class Edge {
    Vertex from;
    Vertex to;
    int weight;
}
