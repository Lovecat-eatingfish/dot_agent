package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

public class LoginHandler extends Handler {
    @Override
    public boolean handle(Request request) {
        if (!request.isLogin()) {
            System.out.println("登录校验失败，拦截请求");
            return false; // 不继续传递
        }
        System.out.println("登录校验通过");
        return true;
    }
}