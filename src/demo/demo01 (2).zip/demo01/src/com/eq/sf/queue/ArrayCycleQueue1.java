package com.eq.sf.queue;

import java.util.Iterator;

public class ArrayCycleQueue1<E> implements Queue<E>, Iterable<E> {
    public int size;
    public  int capacity;
    public  E[] arr;
    public  int tail = 0;
    public  int head = 0;

    public ArrayCycleQueue1(int capacity) {
        this.capacity = capacity;
        this.size = 0;
        this.arr = (E[]) new Object[capacity];
        tail = 0;
        head = 0;
    }

    @Override
    public boolean offer(E value) {
        if (isFull()) {
            System.out.println("队列已满");
            return false;
        }
        arr[tail] = value;
        tail = (tail + 1) % capacity;
        size++;
        return true;
    }

    @Override
    public E poll() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        E poll = arr[head];
        head = (head + 1) % capacity;
        size--;
        return poll;
    }

    @Override
    public E peek() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        return arr[head];
    }

    @Override
    public boolean isEmpty() {
        return tail == head;
    }

    @Override
    public boolean isFull() {
        return (tail + 1) % capacity == head;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int p = head;
            @Override
            public boolean hasNext() {
                return p != tail;
            }

            @Override
            public E next() {
                E value = arr[p];
                p = (p + 1) % capacity;
                return value;
            }
        };
    }
}
