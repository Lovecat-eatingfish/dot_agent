package com.eq.sf.hashtable;

public class HashTable {
    // 拉链节点
    public static class Node {
        Object key;
        Object value;
        Node next;

        public Node(Object key, Object value, Node next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }

    // 当前元素个数
    private int size;
    // 掩码，容量-1，用于hash取模
    private int mask;
    // 哈希桶数组
    private Node[] arr;
    // 负载因子，修正拼写loadFactor
    private final float loadFactor = 0.75f;
    // 扩容阈值，size超过该值触发扩容
    private int threshold;

    public HashTable() {
        this(16);
    }

    public HashTable(int initCapacity) {
        // 容量强制向上取最近2的幂
        int realCap = 1;
        while (realCap < initCapacity) {
            realCap <<= 1;
            // 防止溢出
            if (realCap < 0) {
                realCap = Integer.MAX_VALUE / 2 + 1;
                break;
            }
        }
        this.mask = realCap - 1;
        this.arr = new Node[realCap];
        this.threshold = (int) (realCap * loadFactor);
    }

    /** 新增/覆盖键值对，修复扩容时机BUG */
    public void push(Object key, Object value) {
        int index = getIndex(key);
        Node cur = arr[index];

        // 1. 先遍历，存在则直接覆盖，不扩容、不增加size
        while (cur != null) {
            if (keyEquals(cur.key, key)) {
                cur.value = value;
                return;
            }
            cur = cur.next;
        }

        // 2. 不存在该key，属于新增，先判断扩容再插入
        grow();
        // 扩容后下标可能变化，重新计算index
        index = getIndex(key);
        // 头插法插入新节点
        arr[index] = new Node(key, value, arr[index]);
        size++;
    }

    /** 根据key删除节点，返回被删除节点，无则返回null */
    public Node remove(Object key) {
        int index = getIndex(key);
        Node cur = arr[index];
        Node prev = null;

        while (cur != null) {
            if (keyEquals(cur.key, key)) {
                // 删除头节点
                if (prev == null) {
                    arr[index] = cur.next;
                } else {
                    prev.next = cur.next;
                }
                size--;
                return cur;
            }
            prev = cur;
            cur = cur.next;
        }
        return null;
    }

    /** 根据key查询value，补充缺失功能 */
    public Object get(Object key) {
        int index = getIndex(key);
        Node cur = arr[index];
        while (cur != null) {
            if (keyEquals(cur.key, key)) {
                return cur.value;
            }
            cur = cur.next;
        }
        return null;
    }

    /** 扩容：容量翻倍，高低位拆分链表，不重新计算hash */
    private void grow() {
        // 未达到阈值 / 容量即将溢出，不扩容
        if (size <= threshold || arr.length >= Integer.MAX_VALUE / 2) {
            return;
        }
        int oldLen = arr.length;
        int newLen = oldLen << 1;
        Node[] newArr = new Node[newLen];

        for (int i = 0; i < oldLen; i++) {
            Node cur = arr[i];
            if (cur == null) continue;

            Node lowHead = null, lowTail = null;
            Node highHead = null, highTail = null;

            while (cur != null) {
                Node next = cur.next;
                cur.next = null; // 断开原链表

                Object k = cur.key;
                int hash = (k == null) ? 0 : k.hashCode();
                // hash & oldLen 区分高低桶
                if ((hash & oldLen) != 0) {
                    // 高位桶：新下标 i + oldLen
                    if (highHead == null) {
                        highHead = cur;
                        highTail = cur;
                    } else {
                        highTail.next = cur;
                        highTail = cur;
                    }
                } else {
                    // 低位桶：新下标 i
                    if (lowHead == null) {
                        lowHead = cur;
                        lowTail = cur;
                    } else {
                        lowTail.next = cur;
                        lowTail = cur;
                    }
                }
                cur = next;
            }
            newArr[i] = lowHead;
            newArr[i + oldLen] = highHead;
        }
        // 替换桶数组、掩码、阈值
        arr = newArr;
        mask = newLen - 1;
        threshold = (int) (newLen * loadFactor);
    }

    private int getIndex(Object key) {
        int h;
        int hash = (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
        return hash & mask;
    }


    /** 修复原isSame传参类型BUG：比较两个key是否相等 */
    private boolean keyEquals(Object k1, Object k2) {
        // 引用相等直接true
        if (k1 == k2) return true;
        // 其中一个为null，不相等
        if (k1 == null || k2 == null) return false;
        // hash辅助校验 + equals真正比较内容
        return k1.hashCode() == k2.hashCode() && k1.equals(k2);
    }

    // 辅助方法：获取当前元素总数
    public int size() {
        return size;
    }
}
