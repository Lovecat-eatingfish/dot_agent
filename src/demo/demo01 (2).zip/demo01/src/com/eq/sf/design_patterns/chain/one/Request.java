package com.eq.sf.design_patterns.chain.one;

public class Request {
    private boolean login;
    private boolean permission;
    private String data;

    // getter/setter 省略
    public boolean isLogin() { return login; }
    public void setLogin(boolean login) { this.login = login; }
    public boolean hasPermission() { return permission; }
    public void setPermission(boolean permission) { this.permission = permission; }
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
}