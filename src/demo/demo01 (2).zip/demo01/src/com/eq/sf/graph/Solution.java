package com.eq.sf.graph;

import java.util.*;

public class Solution {


    public List<Vertex> topologicalSort(List<Vertex> vertexList) {
        List<Vertex> result = new ArrayList<>();

        // ✅ 先重置所有节点的入度为0
        for (Vertex v : vertexList) {
            v.indegree = 0;
        }

        for (Vertex v : vertexList) {
            for (Edge e : v.edges) {
                e.to.indegree++;
            }
        }

        Queue<Vertex> queue = new LinkedList<>();
        for (Vertex v : vertexList) {
            if (v.indegree == 0) {
                queue.offer(v);
            }
        }

        while (!queue.isEmpty()) {
            Vertex poll = queue.poll();
            result.add(poll);

            for (Edge e : poll.edges) {
                e.to.indegree--;
                if (e.to.indegree == 0) {
                    queue.offer(e.to);
                }
            }
        }
        return result;
    }

    public List<Vertex> topologicalSort1(List<Vertex> vertexList) {
        List<Vertex> result = new ArrayList<>();

        // ✅ 使用 Map 存储入度，不修改原数据
        Map<Vertex, Integer> indegreeMap = new HashMap<>();
        for (Vertex v : vertexList) {
            indegreeMap.put(v, 0);
        }

        for (Vertex v : vertexList) {
            for (Edge e : v.edges) {
                indegreeMap.put(e.to, indegreeMap.get(e.to) + 1);
            }
        }

        Queue<Vertex> queue = new LinkedList<>();
        for (Vertex v : vertexList) {
            if (indegreeMap.get(v) == 0) {
                queue.offer(v);
            }
        }

        while (!queue.isEmpty()) {
            Vertex poll = queue.poll();
            result.add(poll);

            for (Edge e : poll.edges) {
                indegreeMap.put(e.to, indegreeMap.get(e.to) - 1);
                if (indegreeMap.get(e.to) == 0) {
                    queue.offer(e.to);
                }
            }
        }

        if (result.size() != vertexList.size()) {
            throw new RuntimeException("存在环");
        }
        return result;
    }


    public void Dijkstra(List<Vertex> vertexList, Vertex source) {
        // 初始化距离
        for (Vertex v : vertexList) {
            v.dist = Integer.MAX_VALUE;
            v.visited = false;
            v.prev = null;
        }
        source.dist = 0;

        // ✅ 只将源节点加入队列
        PriorityQueue<Vertex> queue = new PriorityQueue<>(Comparator.comparingInt(v -> v.dist));
        queue.offer(source);

        while (!queue.isEmpty()) {
            Vertex min = queue.poll();

            // ✅ 如果已经访问过，跳过（处理重复节点）
            if (min.visited) {
                continue;
            }

            // ✅ 如果最小距离是无穷大，说明剩下的节点不可达
            if (min.dist == Integer.MAX_VALUE) {
                break;
            }

            min.visited = true;
            updateDist(min, queue);
        }
    }

    private void updateDist(Vertex vertex, PriorityQueue<Vertex> queue) {
        for (Edge e : vertex.edges) {
            Vertex to = e.to;
            if (!to.visited) {
                // ✅ 防止整数溢出
                if (vertex.dist == Integer.MAX_VALUE) {
                    continue;
                }
                int dist = vertex.dist + e.weight;
                if (dist < to.dist) {
                    to.dist = dist;
                    // ✅ 不需要 remove，因为 PriorityQueue 不支持
                    // 直接 offer 新节点，旧节点会在 poll 时被跳过
                    queue.offer(to);
                    to.prev = vertex;
                }
            }
        }
    }


    // 返回值：true=存在负权环
    public boolean bellmanFord(Vertex start, List<Vertex> allVertex, Map<Vertex, Integer> dist) {
        // 初始化距离
        for (Vertex v : allVertex) dist.put(v, Integer.MAX_VALUE);
        dist.put(start, 0);
        int V = allVertex.size();

        // V-1次松弛
        for (int i = 0; i < V - 1; i++) {
            boolean update = false;
            for (Vertex u : allVertex) {
                if (dist.get(u) == Integer.MAX_VALUE) continue;
                for (Edge e : u.edges) {
                    Vertex v = e.to;
                    int w = e.weight;
                    if (dist.get(v) > dist.get(u) + w) {
                        dist.put(v, dist.get(u) + w);
                        update = true;
                    }
                }
            }
            if (!update) break; // 无更新，提前退出
        }

        // 第V轮检测负环
        for (Vertex u : allVertex) {
            if (dist.get(u) == Integer.MAX_VALUE) continue;
            for (Edge e : u.edges) {
                Vertex v = e.to;
                int w = e.weight;
                if (dist.get(v) > dist.get(u) + w) {
                    return true; // 存在负权环
                }
            }
        }
        return false;
    }

}
