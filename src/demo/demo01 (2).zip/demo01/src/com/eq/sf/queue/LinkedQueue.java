package com.eq.sf.queue;

import java.util.Iterator;

public class LinkedQueue<E> implements Iterable<E> , Queue<E>{

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            ListNode<E> p = dummy.next;

            @Override
            public boolean hasNext() {
                return p != null;
            }

            @Override
            public E next() {
                ListNode<E> cur = p;
                p = p.next;
                return cur.value;
            }
        };
    }

    static class ListNode<E> {
        E value;
        ListNode<E> next;

        public ListNode(E value) {
            this.value = value;
        }

        public ListNode() {
        }

        public ListNode(E value, ListNode<E> next) {
            this.value = value;
            this.next = next;
        }
    }

    public int size;
    public int capacity;

    ListNode<E> dummy;
    ListNode<E> tail;

    public LinkedQueue() {
        this.dummy = new ListNode<E>(null);
        tail = dummy;
        capacity = Integer.MAX_VALUE;
        this.size = 0;
    }

    public boolean offer(E value) {
        if (isFull()) {
            return false;
        }
        ListNode<E> node = new ListNode<>(value);
        tail.next = node;
        tail = node;
        size++;
        return true;
    }

    public E poll() {
        if (isEmpty()) {
            return null;
        }
        ListNode<E> pop = dummy.next;
        dummy.next = pop.next;
        // 队列是空的  tail指针需要回归
        if (dummy.next == null) {
            tail = dummy;
        }
        size--;
        return pop.value;
    }

    public E peek() {
        if (isEmpty()) {
            return null;
        }
        ListNode<E> peek = dummy.next;
        return peek.value;
    }

    public boolean isEmpty() {
        // dummy.next = null;
        return size == 0;
    }

    public boolean isFull() {
        // dummy.next != null;
        return size == capacity;
    }

    @Override
    public int size() {
        return size;
    }
}
