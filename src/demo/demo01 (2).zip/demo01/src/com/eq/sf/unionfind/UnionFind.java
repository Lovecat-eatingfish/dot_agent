package com.eq.sf.unionfind;

public class UnionFind {
    int[] parent;
    int[] size;
    int count;

    public UnionFind(int n) {
        parent = new int[n];
        size = new int[n];
        count = n;


        for (int i = 0; i < n; i++) {
            parent[i] = i;
            size[i] = 1;
        }
    }

    public int find(int x) {
        if (parent[x] == x) {
            return x;
        }
        return parent[x] = find(parent[x]);
    }

    public void union(int x, int y) {
        int rootX = find(x);
        int rootY = find(y);

        if (rootX == rootY) {
            return;
        }

        // 确保 rootX 是较大的集合
        if (size[rootY] > size[rootX]) {
            int temp = rootX;
            rootX = rootY;
            rootY = temp;
        }

        // 将小集合 rootY 合并到大集合 rootX
        parent[rootY] = rootX;
        size[rootX] += size[rootY];
        count--;
    }

    public boolean connected(int x, int y) {
        return find(x) == find(y);
    }
}
