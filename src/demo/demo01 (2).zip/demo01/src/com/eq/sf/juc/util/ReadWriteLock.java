package com.eq.sf.juc.util;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ReadWriteLock {
    
    private static class Sync extends AbstractQueuedSynchronizer {
        
        // 高 16 位：读锁计数，低 16 位：写锁计数
        // 读锁（共享锁）需要左移 16 位。  SHARED_UNIT = 1 << SHARED_SHIFT    读锁每次增加的单位。(十进制值： 65536)
        // 作用： 增加一个读锁，就在 state 上加 65536。
        // 3. MAX_COUNT = (1 << SHARED_SHIFT) - 1: 3. MAX_COUNT = (1 << SHARED_SHIFT) - 1
        // 4. EXCLUSIVE_MASK = (1 << SHARED_SHIFT) - 1   含义： 和 MAX_COUNT 完全一样，用于提取写锁（独占锁）的计数。
        private static final int SHARED_SHIFT = 16;
        private static final int SHARED_UNIT = 1 << SHARED_SHIFT;
        private static final int MAX_COUNT = (1 << SHARED_SHIFT) - 1;
        private static final int EXCLUSIVE_MASK = (1 << SHARED_SHIFT) - 1;
        
        // 获取读锁计数
        private int getSharedCount(int c) {
            return c >>> SHARED_SHIFT;
        }
        
        // 获取写锁计数
        private int getExclusiveCount(int c) {
            return c & EXCLUSIVE_MASK;
        }
        
        // 尝试获取读锁（共享模式）
        @Override
        protected int tryAcquireShared(int unused) {
            Thread current = Thread.currentThread();
            int c = getState();
            
            // 如果有写锁且不是当前线程持有，失败
            if (getExclusiveCount(c) > 0 && 
                getExclusiveOwnerThread() != current) {
                return -1;
            }
            
            // 读锁重入
            if (getSharedCount(c) == MAX_COUNT) {
                throw new Error("Maximum lock count exceeded");
            }
            
            // CAS 增加读锁计数
            if (compareAndSetState(c, c + SHARED_UNIT)) {
                // 记录读锁重入次数（简化版）
                return 1;
            }
            return -1;
        }
        
        // 尝试释放读锁
        @Override
        protected boolean tryReleaseShared(int unused) {
            int c = getState();
            int nextc = c - SHARED_UNIT;
            setState(nextc);
            return nextc == 0;  // 所有读锁释放
        }
        
        // 尝试获取写锁（独占模式）
        @Override
        protected boolean tryAcquire(int acquires) {
            Thread current = Thread.currentThread();
            int c = getState();
            int w = getExclusiveCount(c);
            
            if (c != 0) {
                // 有锁
                if (w == 0 || current != getExclusiveOwnerThread()) {
                    return false;  // 有读锁或锁被其他线程持有
                }
                if (w + acquires > MAX_COUNT) {
                    throw new Error("Maximum lock count exceeded");
                }
                setState(c + acquires);
                return true;
            }
            
            // 无锁，尝试获取
            if (compareAndSetState(0, acquires)) {
                setExclusiveOwnerThread(current);
                return true;
            }
            return false;
        }
        
        // 尝试释放写锁
        @Override
        protected boolean tryRelease(int releases) {
            if (!isHeldExclusively()) {
                throw new IllegalMonitorStateException();
            }
            int c = getState() - releases;
            boolean free = getExclusiveCount(c) == 0;
            if (free) {
                setExclusiveOwnerThread(null);
            }
            setState(c);
            return free;
        }
        
        @Override
        protected boolean isHeldExclusively() {
            return getExclusiveOwnerThread() == Thread.currentThread();
        }
    }
    
    private final Sync sync = new Sync();
    private final Lock readLock = new ReadLock();
    private final Lock writeLock = new WriteLock();
    
    private class ReadLock implements Lock {
        @Override
        public void lock() {
            sync.acquireShared(1);
        }
        
        @Override
        public void unlock() {
            sync.releaseShared(1);
        }
        
        @Override
        public boolean tryLock() {
            return sync.tryAcquireShared(1) >= 0;
        }
        
        @Override
        public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
            return sync.tryAcquireSharedNanos(1, unit.toNanos(time));
        }
        
        @Override
        public void lockInterruptibly() throws InterruptedException {
            sync.acquireSharedInterruptibly(1);
        }
        
        @Override
        public Condition newCondition() {
            throw new UnsupportedOperationException();
        }
    }
    
    private class WriteLock implements Lock {
        @Override
        public void lock() {
            sync.acquire(1);
        }
        
        @Override
        public void unlock() {
            sync.release(1);
        }
        
        @Override
        public boolean tryLock() {
            return sync.tryAcquire(1);
        }
        
        @Override
        public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
            return sync.tryAcquireNanos(1, unit.toNanos(time));
        }
        
        @Override
        public void lockInterruptibly() throws InterruptedException {
            sync.acquireInterruptibly(1);
        }
        
        @Override
        public Condition newCondition() {
            throw new UnsupportedOperationException();
        }
    }
    
    public Lock readLock() {
        return readLock;
    }
    
    public Lock writeLock() {
        return writeLock;
    }
}