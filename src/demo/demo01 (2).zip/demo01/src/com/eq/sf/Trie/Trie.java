package com.eq.sf.Trie;

import com.eq.sf.solution.TreeNode;

public class Trie {
    class TrieTree {
        TrieTree[] children = new TrieTree[26];
        boolean isEnd;
    }

    TrieTree root;

    public Trie() {
        root = new TrieTree();
    }

    public void insert(String word) {
        int len = word.length();
        TrieTree cur = root;
        for (int i = 0; i < len; i++) {
            char c = word.charAt(i);
            int index = c - 'a';
            if (cur.children[index] == null) {
                cur.children[index] = new TrieTree();
            }
            cur = cur.children[index];
        }
        cur.isEnd = true;
    }

    public boolean search(String word) {
        TrieTree node = searchWord(word);
        return node != null && node.isEnd;
    }

    public boolean startsWith(String prefix) {
        TrieTree node = searchWord(prefix);
        return node != null;
    }

    public TrieTree searchWord(String word) {
        int len = word.length();
        TrieTree cur = root;

        for (int i = 0; i < len; i++) {
            char c = word.charAt(i);
            int index = c - 'a';
            if (cur.children[index] == null) {
                return null;
            }
            cur = cur.children[index];
        }
        return cur;
    }
}
