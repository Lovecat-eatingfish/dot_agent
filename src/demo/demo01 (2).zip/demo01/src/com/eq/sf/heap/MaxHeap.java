package com.eq.sf.heap;

import java.util.Arrays;

public class MaxHeap {

    int size;
    int[] arr;

    public MaxHeap(int[] arr) {
        this.arr = Arrays.copyOf(arr, arr.length);
        this.size = arr.length;
        buildHeap();
    }

    private void buildHeap() {
        for (int i = (size - 1) / 2; i >= 0; i--) {
            down(i);
        }
    }

    public void offer(int value) {
        grow();

        arr[size] = value;
        size++;
        up(size - 1);
    }

    public int pop() {
        int pop = arr[0];
        size--;
        arr[0] = arr[size];
        down(0);
        return pop;
    }

    public int removeAt(int index) {
        int pop = arr[index];
        size--;
        arr[index] = arr[size];
        down(index);
        up(index);
        return pop;
    }

    public int peek() {
        if (isEmpty()) {
            return -1;
        }
        return arr[0];
    }

    private boolean isEmpty() {
        return size == 0;
    }

    private void grow() {
        if (size == arr.length) {
            int newLength = arr.length * 2;
            arr = Arrays.copyOf(arr, newLength);
        }
    }

    private void up(int index) {
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (arr[index] > arr[parentIndex]) {
                swap(index, parentIndex);
                index = parentIndex;
            } else {
                break;
            }
        }
    }

    private void down(int index) {
        int maxIndex = index;
        int leftIndex = index * 2 + 1;
        int rightIndex = index * 2 + 2;

        if (leftIndex < size && arr[leftIndex] > arr[maxIndex]) {
            maxIndex = leftIndex;
        }
        if (rightIndex < size && arr[rightIndex] > arr[maxIndex]) {
            maxIndex = rightIndex;
        }

        if (maxIndex != index) {
            swap(index, maxIndex);
            down(maxIndex);
        }
    }

    private void swap(int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
