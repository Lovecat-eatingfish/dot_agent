package com.eq.sf.design_patterns.chain.one;

public class LoginHandler extends Handler {
    @Override
    public void handle(Request request) {
        if (!request.isLogin()) {
            System.out.println("登录校验失败，拦截请求");
            return; // 不继续传递
        }
        System.out.println("登录校验通过");

        // 自己控制需不需要向 继续执行逻辑，
        doNext(request); // 传递给下一个处理器

        System.out.println("登录校验处理器后置处理");
    }
}