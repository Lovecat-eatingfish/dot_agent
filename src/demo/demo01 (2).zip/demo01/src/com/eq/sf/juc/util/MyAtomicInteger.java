package com.eq.sf.juc.util;

import sun.misc.Unsafe;

public class MyAtomicInteger {
    private volatile int value;
    private static Unsafe UNSAFE = UnsafeUtil.getUnsafe();
    private static final long VALUE_OFFSET;

    static {
        try {
            VALUE_OFFSET = UNSAFE.objectFieldOffset(
                    MyAtomicInteger.class.getDeclaredField("value")
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public MyAtomicInteger(int value) {
        this.value = value;
    }

    public int get() {
        return value;
    }

    public boolean compareAndSet(int expect, int update) {
        return UNSAFE.compareAndSwapInt(this, VALUE_OFFSET, expect, update);
    }

    public int getAndIncrement() {
        // 要不使用UNSAFE提供的函数
        return UNSAFE.getAndAddInt(this, VALUE_OFFSET, 1);
    }

    public int getAndIncrement1() {
        int oldValue;

        do {
            oldValue = get();
        } while (!compareAndSet(oldValue, oldValue + 1));
        return oldValue;
    }

    public int incrementAndGet() {
        int newValue;
        do {
            newValue = get() + 1;
        } while (!compareAndSet(newValue - 1, newValue));
        return newValue;
    }

    public int getAndAdd(int delta) {
        return UNSAFE.getAndAddInt(this, VALUE_OFFSET, delta);
    }

    public int getAndAdd1(int delta) {
        int oldVal;
        do {
            oldVal = get();
        } while (!compareAndSet(oldVal, oldVal + delta));
        return oldVal;
    }


}
