package com.eq.sf.design_patterns.chain.one;

// 限流处理器
public class RateLimitHandler extends Handler {
    @Override
    public void handle(Request request) {
        if (isRateLimited()) {
            System.out.println("请求被限流，拦截");
            return;
        }
        System.out.println("限流校验通过");
        doNext(request);

        System.out.println("限流校验处理器后置处理");
    }



    private boolean isRateLimited() {
        // 模拟限流逻辑
        return false;
    }
}
