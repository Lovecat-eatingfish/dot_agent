package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

// 业务处理器（最终处理）
public class BusinessHandler extends Handler {
    @Override
    public boolean handle(Request request) {
        System.out.println("执行业务逻辑，处理请求: " + request);
        // 最后一个，不需要调用 doNext
        throw  new RuntimeException("业务路基异常");
    }
}