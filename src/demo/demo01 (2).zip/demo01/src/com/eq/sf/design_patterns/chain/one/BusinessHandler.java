package com.eq.sf.design_patterns.chain.one;

// 业务处理器（最终处理）
public class BusinessHandler extends Handler {
    @Override
    public void handle(Request request) {
        System.out.println("执行业务逻辑，处理请求: " + request);

    }
}