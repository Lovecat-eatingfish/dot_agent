package com.eq.sf.design_patterns.chain.one;

public class Main {
    public static void main(String[] args) {
        // 1. 创建处理器
        LoginHandler loginHandler = new LoginHandler();
        AuthHandler authHandler = new AuthHandler();
        RateLimitHandler rateLimitHandler = new RateLimitHandler();
        BusinessHandler businessHandler = new BusinessHandler();

        // 2. 组装链（顺序很重要）
        loginHandler.setNextHandler(authHandler);
        authHandler.setNextHandler(rateLimitHandler);
        rateLimitHandler.setNextHandler(businessHandler);

        // 3. 创建请求
        Request request = new Request();
        request.setLogin(true);
        request.setPermission(true);
        request.setData("查询用户信息");

        // 4. 从链头开始处理
        try {
            loginHandler.handle(request);
        } finally {
            System.out.println("请求处理完成");
        }
    }
}
