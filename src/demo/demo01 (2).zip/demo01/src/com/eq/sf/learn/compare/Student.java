package com.eq.sf.learn.compare;

public class Student implements Comparable<Student> {

    private String name;
    private int score;

    // 口诀：this - o = 升序，o - this = 降序
    // compareTo返回值
    // 负数 表示升序： this 在 0 前面
    // 0 相等
    // 正数: this > o ， this排在 o后面
    @Override
    public int compareTo(Student o) {
        return this.score - o.score;
    }
}
