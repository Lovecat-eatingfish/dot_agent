package com.eq.sf.juc.solution;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchDemo {
    public static void main(String[] args) throws InterruptedException {
        method2();
    }

    private static void method2() throws InterruptedException {
        Thread t1 = new Thread(() -> {
            System.out.println("线程1执行");
            sleep(1000);
        });
        Thread t2 = new Thread(() -> {
            System.out.println("线程2执行");
            sleep(1000);
        });
        Thread t3 = new Thread(() -> {
            System.out.println("线程3执行");
            sleep(1000);
        });

        t1.start();
        t2.start();
        t3.start();

        // 主线程等待三个线程执行完毕
        t1.join();
        t2.join();
        t3.join();

        System.out.println("三个线程都执行完了，主线程继续");
    }


    private static void method1() throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(3);

        for (int i = 1; i <= 3; i++) {
            int num = i;
            new Thread(() -> {
                System.out.println("线程" + num + "执行");
                sleep(1000);
                latch.countDown();  // 计数器减1
            }).start();
        }

        latch.await();  // 主线程阻塞，等待计数器归零
        System.out.println("三个线程都执行完了，主线程继续");
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}