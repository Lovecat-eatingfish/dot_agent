package com.eq.sf.stack;


import java.util.Iterator;

public class LinkedStack<E> implements Stack<E>, Iterable<E> {

    public ListNode<E> dummy;
    public int size;
    public int capacity;

    public LinkedStack() {
        dummy = new ListNode<>();
        this.size = 0;
        capacity = Integer.MAX_VALUE;
    }

    @Override
    public boolean push(E value) {
        if (isFull()) {
            return false;
        }
        ListNode<E> node = new ListNode<>(value);
        node.next = dummy.next;
        dummy.next = node;
        size++;
        return true;
    }

    @Override
    public E pop() {
        if (isEmpty()) {
            return null;
        }
        ListNode<E> pop = dummy.next;
        dummy.next = pop.next;
        size--;
        return pop.value;
    }

    @Override
    public E peek() {
        if (isEmpty()) {
            return null;
        }
        ListNode<E> pop = dummy.next;
        return pop.value;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean isFull() {
        return size == capacity;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            ListNode<E> p = dummy.next;
            @Override
            public boolean hasNext() {
                return p != null;
            }

            @Override
            public E next() {
                E value = p.value;
                p = p.next;
                return value;
            }
        };
    }

    public static class ListNode<E> {
        E value;
        ListNode<E> next;

        public ListNode(E value) {
            this.value = value;
        }

        public ListNode() {
        }

        public ListNode(E value, ListNode<E> next) {
            this.value = value;
            this.next = next;
        }
    }
}
