package com.eq.sf.juc.solution;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class PrintJORen {
    public static void main(String[] args) throws InterruptedException {
        PrintJORen printJO = new PrintJORen(101);
        Thread even = new Thread(printJO::printEven);
        Thread odd = new Thread(printJO::printOdd);

        even.start();
        odd.start();


        even.join();
        odd.join();
    }

    private ReentrantLock lock = new ReentrantLock();
    // oddCon 是奇数线程用来等待的条件
    private Condition oddCon = lock.newCondition();
    private Condition evenCond = lock.newCondition();

    int count = 1;
    int max;

    public PrintJORen(int max) {
        this.max = max;
    }

    // 打印奇数
    public void printOdd() {
        lock.lock();
        try {
            while (count <= max) {
                // 当前偶数， 不满足奇数条件， 所以奇数线程等大
                while (count % 2 == 0) {
                    oddCon.await();
                }
                // 满足条件 当前是奇数
                if (count <= max) {
                    System.out.println(count);
                    count++;
                    evenCond.signal();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }

    }

    // 打印偶数
    public void printEven() {
        lock.lock();
        try {
            while (count <= max) {
                while (count % 2 == 1) {
                    evenCond.await();
                }

                if (count <= max) {
                    System.out.println(count);
                    count++;
                    oddCon.signal();
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }
}
