package com.eq.sf.solution;

import javafx.util.Pair;

import java.util.*;

public class Solution {

    // 钢锯条切分问题
    // 参数含义：长度对应的价值，   当前钢锯条的总长度
    public static int cutRodBottomUp(int[] prices, int n) {
        // 长度为 i 的钢锯条的 总价值：dp[i];
        int[] dp = new int[n + 1];

        // 完全背包问题 prices 里面的可以被重复使用
        for (int price : prices) {
            for (int i = 0; i <= n; i++) {
                if (i < price) {
                    dp[i] = dp[i];
                } else {
                    dp[i] = Math.max(dp[i], dp[i - price] + price);
                }
            }
        }
        return dp[n];
    }

    /**
     * 钢条切割 - 动态规划
     *
     * @param prices 价格表，prices[i]表示长度为i的钢条价格
     * @param n      钢条总长度
     * @return 最大收益
     */
    public static int cutRod(int[] prices, int n) {
        // dp[i] 表示长度为 i 的钢条的最大收益
        int[] dp = new int[n + 1];
        dp[0] = 0;

        // 外层：钢条总长度从1到n
        for (int i = 1; i <= n; i++) {
            // 内层：第一刀切下长度为j（1 <= j <= i）
            for (int j = 1; j <= i; j++) {
                // 切下长度j，获得价值prices[j]，剩余长度i-j继续最优切割
                dp[i] = Math.max(dp[i], dp[i - j] + prices[j]);
            }
        }
        return dp[n];
    }


    public String largestNumber(int[] nums) {
        int len = nums.length;
        String[] arr = new String[len];
        for (int i = 0; i < len; i++) {
            arr[i] = String.valueOf(nums[i]);
        }

        // 关键：自定义比较器: 返回值 小于0  b + a 在前面
        Arrays.sort(arr, (a, b) -> (b + a).compareTo(a + b));

        // 处理全是 0 的情况（比如 [0, 0]）
        if (arr[0].equals("0")) {
            return "0";
        }

        StringBuilder result = new StringBuilder();
        for (String str : arr) {
            result.append(str);
        }
        return result.toString();
    }

    // 二叉树的最大宽度
    public int widthOfBinaryTree(TreeNode root) {
        if (root == null) return 0;

        int maxWidth = 0;
        Queue<Pair<TreeNode, Integer>> queue = new LinkedList<>();
        queue.offer(new Pair<>(root, 1));

        while (!queue.isEmpty()) {
            int size = queue.size();
            int left = queue.peek().getValue();   // 当前层最左节点的编号
            int right = left;                     // 初始化为 left

            for (int i = 0; i < size; i++) {
                Pair<TreeNode, Integer> pair = queue.poll();
                TreeNode node = pair.getKey();
                int index = pair.getValue();
                right = index;  // 更新为当前节点的编号（循环结束就是最右节点）

                if (node.left != null) {
                    queue.offer(new Pair<>(node.left, index * 2));
                }
                if (node.right != null) {
                    queue.offer(new Pair<>(node.right, index * 2 + 1));
                }
            }

            maxWidth = Math.max(maxWidth, right - left + 1);  // 注意 +1
        }

        return maxWidth;
    }


    // 求二叉树的最长直径： 两个节点之间的边的最多个数 ==》 等价于 每个节点的 最大深度 / 高度  的最大值就是题目答案
    int result = 0;

    public int diameterOfBinaryTree(TreeNode root) {
        dfs(root);
        return result;
    }

    private int dfs(TreeNode root) {
        if (root == null) {
            return 0;
        }
        int left = dfs(root.left);
        int right = dfs(root.right);
        result = Math.max(result, left + right);
        return Math.max(left, right) + 1;
    }


    // 寻找峰值
    public int findPeakElement(int[] nums) {
        int len = nums.length;
        int left = 0;
        int right = len - 1;
        while (left < right) {
            int mid = (left + right) / 2;
            if (nums[mid] < nums[mid + 1]) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        return left;
    }

    // 和为k的子数组的个数 前缀和
    // k 是 sum 向前 - k 的意思
    public int subarraySum(int[] nums, int k) {
        int sum = 0;
        int result = 0;

        Map<Integer, Integer> count = new HashMap<>();
        count.put(0, 1);  // 前缀和为 0 出现 1 次（空数组）

        for (int num : nums) {
            sum += num;  // 当前前缀和

            // 检查是否存在前缀和 sum - k
            if (count.containsKey(sum - k)) {
                result += count.get(sum - k);
            }

            // 更新当前前缀和的出现次数
            count.put(sum, count.getOrDefault(sum, 0) + 1);
        }
        return result;
    }

    // 根节点到叶子节点的和 == target的路径
    List<List<Integer>> result1 = new ArrayList<>();
    LinkedList<Integer> path1 = new LinkedList<>();

    public List<List<Integer>> pathSum(TreeNode root, int targetSum) {
        dfsPathSum(root, targetSum);
        return result1;
    }

    private void dfsPathSum(TreeNode node, int currentSum) {
        if (node == null) {
            return;
        }

        path1.add(node.val);
        if (node.left == null && node.right == null && currentSum == node.val) {
            result1.add(new ArrayList<>(path1));
            // 不要return 需要让他去 会朔一下: 删除这个节点
        }

        dfsPathSum(node.left, currentSum - node.val);
        dfsPathSum(node.right, currentSum - node.val);

        path1.removeLast();
    }


    // 两个两个交换链表的节点
    public ListNode swapPairs(ListNode head) {
        ListNode dummy = new ListNode();
        dummy.next = head;

        ListNode prev = dummy;
        while (prev.next != null && prev.next.next != null) {
            ListNode left = prev.next;
            ListNode right = prev.next.next;

            left.next = right.next;
            right.next = left;
            prev.next = right;

            prev = left;
        }
        return dummy.next;
    }


    // 找出该数组中满足其总和大于等于 target 的长度最小的 子数组
    public int minSubArrayLen(int target, int[] nums) {
        int sum = 0;
        int left = 0;
        int right = 0;
        int len = nums.length;
        int result = Integer.MAX_VALUE;

        while (right < len) {
            int r = nums[right];
            right++;
            sum += r;

            while (sum >= target) {
                result = Math.min(result, right - left);

                int l = nums[left];
                left++;
                sum -= l;
            }
        }
        return result == Integer.MAX_VALUE ? 0 : result;
    }

    // 打家劫舍 一
    public int rob(int[] nums) {
        int len = nums.length;
        if (len == 1) {
            return nums[0];
        }
        int[] dp = new int[len];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[1], nums[0]);

        for (int i = 2; i < len; i++) {
            dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i]);
        }
        return dp[len - 1];
    }

    public int rob2(int[] nums) {
        int len = nums.length;
        // ✅ 边界情况：只有一个房子
        if (len == 1) {
            return nums[0];
        }
        return Math.max(robSub(nums, 0, len - 2), robSub(nums, 1, len - 1));
    }

    private int robSub(int[] nums, int left, int right) {
        int one = nums[left];
        int two = Math.max(nums[left], nums[left + 1]);

        int three;
        for (int i = left + 2; i <= right; i++) {
            three = Math.max(one + nums[i], two);
            one = two;
            two = three;
        }
        return two;
    }

    public int rob3(TreeNode root) {
        int[] arr = robSub2(root);
        return Math.max(arr[0], arr[1]);
    }

    private int[] robSub2(TreeNode node) {
        if (node == null) {
            return new int[]{0, 0};
        }
        int[] left = robSub2(node.left);
        int[] right = robSub2(node.right);

        int noRob = Math.max(left[0], left[1]) + Math.max(right[0], right[1]);
        int rob = node.val + left[0] + right[0];
        return new int[]{noRob, rob};
    }

    // 判断是不是有 从root 到叶子节点 的和的路径 == target
    public boolean hasPathSum(TreeNode root, int targetSum) {
        if (root == null) {
            return false;
        }
        if (root.left == null && root.right == null && targetSum == root.val) {
            return true;
        }

        boolean l = hasPathSum(root.left, targetSum - root.val);
        boolean r = hasPathSum(root.right, targetSum - root.val);

        return l || r;
    }


    // 删除链表中重复的元素 重复元素保留一个就好了
    public ListNode deleteDuplicates(ListNode head) {
        ListNode fast = head;


        while (fast != null && fast.next != null) {
            if (fast.val == fast.next.val) {
                fast.next = fast.next.next;
            } else {
                fast = fast.next;
            }
        }
        return head;
    }

    public boolean wordBreak(String s, List<String> wordDict) {
        int len = s.length();
        Set<String> set = new HashSet<>(wordDict);
        boolean[] dp = new boolean[len + 1];
        dp[0] = true;
        // 先便利 j 在遍历 i
        for (int j = 1; j <= len; j++) {
            for (int i = 0; i < j; i++) {
                String sub = s.substring(i, j);
                if (dp[i] && set.contains(sub)) {
                    dp[j] = true;
                    break;
                }
            }
        }
        return dp[len];
    }


    // 通用表达式计算问题
    Map<Character, Integer> map = new HashMap<>();

    public int calculate(String s) {
        map.put('+', 1);
        map.put('-', 1);
        map.put('*', 2);
        map.put('/', 2);
        map.put('^', 3);

        s = s.replace(" ", "");
        char[] arr = s.toCharArray();
        int len = arr.length;

        Deque<Integer> nums = new ArrayDeque<>();
        Deque<Character> ops = new ArrayDeque<>();
        nums.offer(0);  // 处理以 '-' 开头的情况

        for (int i = 0; i < len; i++) {
            char c = arr[i];

            if (c == '(') {
                ops.addLast(c);
                // 处理 "(-" 这种情况
                if (i + 1 < len && arr[i + 1] == '-') {
                    nums.offer(0);
                }
            } else if (c == ')') {
                // 计算直到遇到 '('
                while (!ops.isEmpty()) {
                    char top = ops.peekLast();
                    if (top == '(') {
                        ops.pollLast();  // 弹出 '('
                        break;
                    } else {
                        calc(nums, ops);
                    }
                }
            } else if (Character.isDigit(c)) {
                int num = 0;
                int j = i;
                while (j < len && Character.isDigit(arr[j])) {
                    num = num * 10 + (arr[j] - '0');
                    j++;
                }
                nums.addLast(num);
                i = j - 1;
            } else {
                // 处理运算符
                while (!ops.isEmpty() && ops.peekLast() != '('
                        && map.get(c) <= map.get(ops.peekLast())) {
                    calc(nums, ops);
                }
                ops.addLast(c);
            }
        }

        while (!ops.isEmpty()) {
            calc(nums, ops);
        }
        return nums.pollLast();
    }

    private void calc(Deque<Integer> nums, Deque<Character> ops) {
        if (nums.size() < 2 || ops.isEmpty()) return;

        int b = nums.pollLast();
        int a = nums.pollLast();
        char op = ops.pollLast();
        int res = 0;

        switch (op) {
            case '+':
                res = a + b;
                break;
            case '-':
                res = a - b;
                break;
            case '*':
                res = a * b;
                break;
            case '/':
                res = a / b;
                break;
            case '^':
                res = (int) Math.pow(a, b);
                break;
        }
        nums.addLast(res);
    }


    // 最长重复子数组
//    public int findLength(int[] nums1, int[] nums2) {
//        int len1 = nums1.length;
//        int len2 = nums2.length;
//        int result = 0;
//
//        // dp[i][j] 表示以 nums1[i-1] 和 nums2[j-1] 结尾的最长重复子数组长度。
//        // 但最长重复子数组不一定在最后一位结束，所以需要遍历所有 dp 值取最大！
//        int[][] dp = new int[len1 + 1][len2 + 1];
//
//        for (int i = 1; i <= len1; i++) {
//            for (int j = 1; j <= len2; j++) {
//                if (nums1[i - 1] == nums2[j - 1]) {
//                    dp[i][j] = dp[i - 1][j - 1] + 1;
//                    result = Math.max(result, dp[i][j]);  // ✅ 记录最大值
//                }
//            }
//        }
//        return result;
//    }

    // 多数元素
    public int majorityElement(int[] nums) {
        int count = 1;
        int candidate = nums[0];

        for (int i = 1; i < nums.length; i++) {
            if (count == 0) {
                candidate = nums[i];
                count = 1;
            } else if (candidate == nums[i]) {
                count++;
            } else {
                count--;
            }
        }
        return candidate;
    }

    // 课程表问题: 参数一： 节点个数， 参数二就是有向边
    public boolean canFinish(int numCourses, int[][] prerequisites) {
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < numCourses; i++) {
            graph.add(new ArrayList<>());
        }
        int[] indegree = new int[numCourses];
        for (int[] pre : prerequisites) {
            int from = pre[1];
            int to = pre[0];
            graph.get(from).add(to);
            indegree[to]++;
        }

        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < numCourses; i++) {
            if (indegree[i] == 0) {
                queue.offer(i);
            }
        }
        int count = 0;
        while (!queue.isEmpty()) {
            int poll = queue.poll();
            count++;
            for (int neighbor : graph.get(poll)) {
                indegree[neighbor]--;
                if (indegree[neighbor] == 0) {
                    queue.offer(neighbor);
                }
            }
        }
        return count == numCourses;
    }


    // 堆排序
    public void heapSort(int[] arr) {
        buildHeap(arr);

        // 2. 排序
        for (int i = arr.length - 1; i > 0; i--) {  // ✅ i > 0，最后一个元素不需要再调整
            swap(arr, 0, i);        // 堆顶放到末尾
            down(arr, 0, i);        // ✅ 传入堆的大小 i（不包括已排好的部分）
        }
    }

    private void buildHeap(int[] arr) {
        for (int i = (arr.length - 1) / 2; i >= 0; i--) {
            down(arr, i, arr.length);
        }
    }


    private void down(int[] arr, int index, int heapSize) {  // ✅ 添加 heapSize 参数
        int maxIndex = index;
        int left = index * 2 + 1;
        int right = index * 2 + 2;

        // ✅ 正确的边界检查
        if (left < heapSize && arr[left] > arr[maxIndex]) {
            maxIndex = left;
        }
        if (right < heapSize && arr[right] > arr[maxIndex]) {
            maxIndex = right;
        }

        // ✅ 只有在需要交换时才递归
        if (maxIndex != index) {
            swap(arr, maxIndex, index);
            down(arr, maxIndex, heapSize);
        }
        // 如果 maxIndex == index，直接返回（递归终止）
    }


    private void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }


    // 单词检索
    boolean[][] visited;
    int m;
    int n;

    public boolean exist(char[][] board, String word) {
        m = board.length;
        n = board[0].length;

        visited = new boolean[m][n];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (dfs(board, word, i, j, 0)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean dfs(char[][] board, String word, int i, int j, int index) {
        if (index == word.length()) {
            return true;
        }
        if (i < 0 || i >= m || j < 0 || j >= n || word.charAt(index) != board[i][j] || visited[i][j]) {
            return false;
        }
        visited[i][j] = true;

        boolean flag = dfs(board, word, i + 1, j, index + 1)
                || dfs(board, word, i - 1, j, index + 1)
                || dfs(board, word, i, j + 1, index + 1)
                || dfs(board, word, i, j - 1, index + 1);

        visited[i][j] = false;

        return flag;
    }


    // 验证ip地址
    public String validIPAddress(String queryIP) {
        if (queryIP.contains(".")) {
            return validateIPv4(queryIP) ? "IPv4" : "Neither";
        } else if (queryIP.contains(":")) {
            return validateIPv6(queryIP) ? "IPv6" : "Neither";
        } else {
            return "Neither";
        }
    }

    // ============ IPv4 校验 ============
    private boolean validateIPv4(String ip) {
        // 1. 分割
        String[] parts = ip.split("\\.");

        // 2. 必须恰好 4 段
        if (parts.length != 4) return false;

        // 3. 逐段校验
        for (String part : parts) {
            // 3.1 不能为空
            if (part.isEmpty()) return false;

            // 3.2 不能有前导零（长度 > 1 且以 '0' 开头）
            if (part.length() > 1 && part.charAt(0) == '0') return false;

            // 3.3 必须全是数字
            for (char c : part.toCharArray()) {
                if (!Character.isDigit(c)) return false;
            }

            // 3.4 数值范围 0-255
            int num = Integer.parseInt(part);
            if (num < 0 || num > 255) return false;
        }
        return true;
    }

    // ============ IPv6 校验 ============
    private boolean validateIPv6(String ip) {
        // 1. 分割
        String[] parts = ip.split(":");

        // 2. 必须恰好 8 段
        if (parts.length != 8) return false;

        // 3. 逐段校验
        for (String part : parts) {
            // 3.1 长度 1-4
            if (part.length() < 1 || part.length() > 4) return false;

            // 3.2 必须是十六进制字符
            for (char c : part.toCharArray()) {
                if (!isHexDigit(c)) return false;
            }
        }
        return true;
    }

    // ============ 辅助方法 ============
    private boolean isHexDigit(char c) {
        return (c >= '0' && c <= '9') ||
                (c >= 'a' && c <= 'f') ||
                (c >= 'A' && c <= 'F');
    }


    // 每日温度: 下一个更高的温度出现在几天后
    // 单调递减栈
    public int[] dailyTemperatures(int[] temperatures) {
        int len = temperatures.length;
        int[] result = new int[len];

        Stack<Integer> stack = new Stack<>();
        stack.push(0);
        for (int i = 1; i < len; i++) {
            if (!stack.isEmpty() && temperatures[i] <= temperatures[stack.peek()]) {
                stack.push(i);
            } else {
                while (!stack.isEmpty() && temperatures[i] > temperatures[stack.peek()]) {
                    int index = stack.pop();
                    result[index] = i - index;
                }
                stack.push(i);
            }
        }
        return result;
    }


    // 旋转排序数组 找最小值
    public int findMin(int[] nums) {
        int len = nums.length;
        int left = 0;
        int right = len - 1;
        while (left < right) {
            int mid = (left + right) / 2;
            if (nums[mid] > nums[right]) {
                left = mid + 1;
            } else if (nums[mid] < nums[right]) {
                right = mid;
            } else {
                right--;
            }
        }
        return nums[left];
    }

    // 随机链表复制
    public Node copyRandomList(Node head) {
        Map<Node, Node> mapping = new HashMap<>();
        Node cur = head;
        while (cur != null) {
            mapping.put(cur, new Node(cur.val));
            cur = cur.next;
        }

        cur = head;
        while (cur != null) {
            Node newNode = mapping.get(cur);
            newNode.random = mapping.get(cur.random);
            newNode.next = mapping.get(cur.next);
            cur = cur.next;
        }
        return mapping.get(head);
    }

    // 有重复元素的全排类问题， 返回不能有重复的排列
    // 给定一个可包含重复数字的序列 nums ，按任意顺序 返回所有不重复的全排列。
    List<List<Integer>> result2 = new ArrayList<>();
    LinkedList<Integer> path2 = new LinkedList<>();
    boolean[] used;

    public List<List<Integer>> permuteUnique(int[] nums) {
        used = new boolean[nums.length];
        Arrays.sort(nums);
        dfs2(nums);
        return result2;
    }

    private void dfs2(int[] nums) {
        if (path2.size() == nums.length) {
            result2.add(new ArrayList<>(path2));
            return;
        }
        for (int i = 0; i < nums.length; i++) {
            // ✅ 去重逻辑正确
            if (i > 0 && nums[i] == nums[i - 1] && !used[i - 1]) {
                continue;
            }

            if (used[i]) continue;  // ✅ 需要这行！

            path2.add(nums[i]);
            used[i] = true;

            dfs2(nums);

            path2.removeLast();
            used[i] = false;
        }
    }


    // 跳跃游戏
    public boolean canJump(int[] nums) {
        int len = nums.length;
        boolean[] dp = new boolean[len];

        dp[0] = true;

        for (int j = 1; j < len; j++) {
            for (int i = 0; i < j; i++) {
                if (dp[i] && i + nums[i] >= j) {
                    dp[j] = true;
                    break;
                }
            }
        }
        return dp[len - 1];
    }


    // 给定一个候选人编号的集合 candidates 和一个目标数 target ，找出 candidates 中所有可以使数字和为 target 的组合。
    // candidates 中的每个数字在每个组合中只能使用 一次 。
    // 数组元素可以重复， 但是 不能有重复的组合 比如  1 2 2 的问题 只能由一个
    public List<List<Integer>> combinationSum2(int[] candidates, int target) {
        Arrays.sort(candidates);
        backtracking(candidates, target, 0, 0);
        return result2;
    }

    private void backtracking(int[] candidates, int target, int currentSum, int startIndex) {
        if (currentSum == target) {
            result2.add(new ArrayList<>(path2));
            return;
        }
        if (currentSum > target) {
            return;
        }
        for (int i = startIndex; i < candidates.length; i++) {
            if (i > startIndex && candidates[i] == candidates[i - 1]) {
                continue;
            }

            path2.add(candidates[i]);

            backtracking(candidates, target, currentSum + candidates[i], i + 1);

            path2.removeLast();
        }
    }

    // 距离target最近的三个数字之和 的值
    public int threeSumClosest(int[] nums, int target) {
        Arrays.sort(nums);
        int n = nums.length;
        int closest = nums[0] + nums[1] + nums[2];  // 初始值

        for (int i = 0; i < n - 2; i++) {
            // 小优化：跳过重复的i（可选）
            if (i > 0 && nums[i] == nums[i - 1]) {
                continue;
            }

            int left = i + 1;
            int right = n - 1;

            while (left < right) {
                int sum = nums[i] + nums[left] + nums[right];

                // 如果和等于target，直接返回
                if (sum == target) {
                    return sum;
                }

                // 更新最接近的值
                if (Math.abs(sum - target) < Math.abs(closest - target)) {
                    closest = sum;
                }

                // 移动指针
                if (sum < target) {
                    left++;
                    // 跳过重复的left（可选）
                    while (left < right && nums[left] == nums[left - 1]) {
                        left++;
                    }
                } else {
                    right--;
                    // 跳过重复的right（可选）
                    while (left < right && nums[right] == nums[right + 1]) {
                        right--;
                    }
                }
            }
        }
        return closest;
    }


    // 移掉k位数字， 让数字尽可能的小
    // 单调栈问题： 核心思路是：移除高位的大数字，让更小的数字占据高位。
    // 单调递增的栈
    public static String removeKdigits(String num, int k) {
        if (k >= num.length()) return "0";

        Stack<Character> stack = new Stack<>();
        for (char digit : num.toCharArray()) {
            while (!stack.isEmpty() && k > 0 && stack.peek() > digit) {
                stack.pop();
                k--;
            }
            stack.push(digit);
        }

        System.out.println(stack);

        while (k > 0) {
            stack.pop();
            k--;
        }

        System.out.println(stack);

        StringBuilder sb = new StringBuilder();
        while (!stack.isEmpty()) {
            char c = stack.pop();  // 从栈底取
            if (sb.length() == 0 && c == '0') {
                continue;
            }
            sb.append(c);
        }
        return sb.length() == 0 ? "0" : sb.reverse().toString();
    }

    // 逆序对的个数
    public int reversePairs(int[] record) {
        return sortArr(record, 0, record.length - 1);
    }

    private int sortArr(int[] record, int left, int right) {
        if (left >= right) {
            return 0;
        }
        int result = 0;
        int mid = (left + right) / 2;
        result += sortArr(record, left, mid);
        result += sortArr(record, mid + 1, right);
        result += mergeArray(record, left, mid, right);
        return result;
    }

    private int mergeArray(int[] record, int left, int mid, int right) {
        int i = left;
        int j = mid + 1;
        int result = 0;

        int[] temp = new int[right - left + 1];
        int k = 0;
        while (i <= mid && j <= right) {
            if (record[i] > record[j]) {
                result += mid - i + 1;
                temp[k] = record[j];
                j++;
            } else {
                temp[k] = record[i];
                i++;
            }
            k++;
        }
        while (i <= mid) {
            temp[k++] = record[i++];
        }
        while (j <= right) {
            temp[k++] = record[j++];
        }

        System.arraycopy(temp, 0, record, left, k);
        return result;
    }


    // 旋转链表 吧链表整体右移动 k 个节点的位置
    public ListNode rotateRight(ListNode head, int k) {
        if (head == null) {
            return null;
        }
        int len = 0;
        ListNode cur = head;
        while (cur != null) {
            len++;
            cur = cur.next;
        }

        k = k % len;
        if (k == 0) {
            return head;
        }

        cur = head;
        for (int i = 0; i < len - k - 1; i++) {
            cur = cur.next;
        }

        ListNode newHead = cur.next;
        ListNode oldHead = head;
        cur.next = null;

        cur = newHead;
        while (cur.next != null) {
            cur = cur.next;
        }
        cur.next = oldHead;
        return newHead;
    }


    // 归并排序
    public int[] sortArray(int[] nums) {
        sortArr1(nums, 0, nums.length - 1);
        return nums;
    }

    private void sortArr1(int[] record, int left, int right) {
        if (left >= right) {
            return;
        }
        int mid = (left + right) / 2;
        sortArr(record, left, mid);
        sortArr(record, mid + 1, right);
        mergeArray1(record, left, mid, right);
    }

    private void mergeArray1(int[] record, int left, int mid, int right) {
        int i = left;
        int j = mid + 1;

        int[] temp = new int[right - left + 1];
        int k = 0;
        while (i <= mid && j <= right) {
            if (record[i] > record[j]) {
                temp[k] = record[j];
                j++;
            } else {
                temp[k] = record[i];
                i++;
            }
            k++;
        }
        while (i <= mid) {
            temp[k++] = record[i++];
        }
        while (j <= right) {
            temp[k++] = record[j++];
        }

        System.arraycopy(temp, 0, record, left, k);
    }

    // 两个数组的最长重复子数组
    public int findLength(int[] nums1, int[] nums2) {
        int len1 = nums1.length;
        int len2 = nums2.length;

        // 两个数组前i 和 j 个元素的最长重复子数组的长度, 其实这个就是一个局部的最值， 所以需要result max 来获取最大值
        int result = 0;
        int[][] dp = new int[len1 + 1][len2 + 1];

        for (int i = 1; i <= len1; i++) {
            for (int j = 1; j <= len2; j++) {
                if (nums1[i - 1] == nums2[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                    result = Math.max(result, dp[i][j]);
                }
            }
        }
        return result;
    }

    // 颜色分类问题
    public void sortColors(int[] nums) {
        int len = nums.length;
        int left = 0;
        int right = len - 1;
        int cur = 0;

        while (cur <= right) {
            if (nums[cur] == 0) {
                swap(nums, left, cur);
                left++;
                cur++;
            } else if (nums[cur] == 1) {
                cur++;
            } else {
                swap(nums, cur, right);
                right--;
            }
        }
    }

    // 零钱兑换 求方法的个数 完全背包问题
    // 要： dp[i][j - coin]
    // 不要 dp[i - 1][j]
    public int change(int amount, int[] coins) {
        int[] dp = new int[amount + 1];
        dp[0] = 1;

        for (int coin : coins) {
            for (int j = 0; j <= amount; j++) {
                if (j < coin) {
                    dp[j] = dp[j];
                } else {
                    dp[j] = dp[j] + dp[j - coin];
                }
            }
        }
        return dp[amount];
    }

    // 树的子结构判断
    public boolean isSubStructure(TreeNode A, TreeNode B) {
        if (A == null || B == null) {
            return false;
        }
        if (isSub(A, B)) {
            return true;
        }
        return isSubStructure(A.left, B) || isSubStructure(A.right, B);
    }

    private boolean isSub(TreeNode a, TreeNode b) {
        // ✅ B 为空说明匹配完成
        if (b == null) {
            return true;
        }
        // ✅ A 为空但 B 不为空，匹配失败
        if (a == null) {
            return false;
        }
        // ✅ 当前节点值相等，且左右子树都匹配
        if (a.val != b.val) {
            return false;
        }
        return isSub(a.left, b.left) && isSub(a.right, b.right);
    }


    // 判断子树
    public boolean isSubtree(TreeNode root, TreeNode subRoot) {
        if (root == null && subRoot == null) {
            return true;
        }
        if (root == null || subRoot == null) {
            return false;
        }
        if (isSameTree(root, subRoot)) {
            return true;
        }
        return isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot);
    }

    private boolean isSameTree(TreeNode p, TreeNode q) {
        if (q == null && p == null) {
            return true;
        }

        if (p == null || q == null) {
            return false;
        }
        return isSameTree(p.left, q.left) && isSameTree(p.right, q.right) && p.val == q.val;
    }

    public double myPow(double x, int n) {
        // 用 long 接收，防止 -n 溢出
        long N = n;

        // 负指数：取倒数，指数取正
        if (N < 0) {
            x = 1 / x;
            N = -N;
        }

        double result = 1.0;
        double base = x;

        // 快速幂核心：根据 N 的二进制位来累乘
        while (N > 0) {
            // 如果当前最低位是 1，结果乘上 base
            if ((N & 1) == 1) {
                result *= base;
            }
            // base 不断平方：x -> x^2 -> x^4 -> x^8 ...
            base *= base;
            // N 右移一位，处理下一位
            N >>= 1;
        }

        return result;
    }


    // 验证回文串
    // 输入: s = "A man, a plan, a canal: Panama"
    // 输出：true
    // 解释："amanaplanacanalpanama" 是回文串
    public boolean isPalindrome(String s) {
        int len = s.length();
        int left = 0;
        int right = len - 1;

        while (left < right) {
            while (left < right && !Character.isLetterOrDigit(s.charAt(left))) {
                left++;
            }

            while (left < right && !Character.isLetterOrDigit(s.charAt(right))) {
                right--;
            }

            if (Character.toLowerCase(s.charAt(left)) != Character.toLowerCase(s.charAt(right))) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }

    // 分发糖果
    public int candy(int[] ratings) {
        int len = ratings.length;
        int[] result = new int[len];
        Arrays.fill(result, 1);

        for (int i = 1; i < len; i++) {
            if (ratings[i] > ratings[i - 1]) {
                result[i] = result[i - 1] + 1;
            }
        }

        for (int i = len - 2; i >= 0; i--) {
            if (ratings[i] > ratings[i + 1]) {
                result[i] = Math.max(result[i], result[i + 1] + 1);
            }
        }
        int sum = 0;
        for (int n : result) {
            sum += n;
        }
        return sum;
    }


    // 整数反转
    public int reverse(int x) {
        long num = x;          // 用 long 接收，防止 -x 溢出
        long result = 0;

        while (num != 0) {
            result = result * 10 + num % 10;
            num /= 10;
        }

        // 检查是否溢出 int 范围
        if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
            return 0;           // 根据题意，溢出返回 0
        }
        return (int) result;
    }

    // 给定一个奇数位升序，偶数位降序的链表，将其重新排序。
    public ListNode sortLinkedList(ListNode head) {
        // 处理空链表或单节点的情况
        if (head == null || head.next == null) return head;

        ListNode ji = new ListNode();
        ListNode ou = new ListNode();
        ListNode jp = ji, op = ou;
        ListNode cur = head;

        // 1. 拆分奇偶链表，并断开原链接
        while (cur != null) {
            ListNode next = cur.next;
            cur.next = null;  // 关键：断开原链接

            if ((cur.val & 1) == 1) {  // 位运算判断奇数，效率略高
                jp.next = cur;
                jp = jp.next;
            } else {
                op.next = cur;
                op = op.next;
            }
            cur = next;
        }

        // 2. 反转偶数链表（偶数位是降序，反转后变为升序）
        ListNode reversedOu = reverse(ou.next);
        ListNode sortedJi = ji.next;

        // 3. 合并两个升序链表（归并）
        ListNode dummy = new ListNode();
        ListNode tail = dummy;
        while (sortedJi != null && reversedOu != null) {
            if (sortedJi.val <= reversedOu.val) {
                tail.next = sortedJi;
                sortedJi = sortedJi.next;
            } else {
                tail.next = reversedOu;
                reversedOu = reversedOu.next;
            }
            tail = tail.next;
        }
        tail.next = (sortedJi != null) ? sortedJi : reversedOu;

        return dummy.next;
    }

    public ListNode reverse(ListNode head) {
        ListNode cur = head;
        ListNode prev = null;
        while (cur != null) {
            ListNode next = cur.next;
            cur.next = prev;
            prev = cur;
            cur = next;
        }
        return prev;
    }

    // 找到数组中的重复数字
    // 前提： 给你一个长度为 n 的整数数组 nums ，其中 nums 的所有整数都在范围 [1, n] 内，且每个整数出现 最多两次 。请你找出所有出现 两次 的整数，并以数组形式返回。
    public List<Integer> findDuplicates(int[] nums) {
        // 解释映射含义： 数组长度： n， 元素范围： 1到 n ， 下表： 0到n - 1
        // 如果出现两个三 第一个三  吧下标2 标记为 负数
        List<Integer> result = new ArrayList<>();
        int len = nums.length;
        for (int i = 0; i < len; i++) {
            int num = Math.abs(nums[i]);

            int index = num - 1;
            if (nums[index] < 0) {
                result.add(num);
            } else {
                nums[index] = -nums[index];
            }
        }
        return result;
    }


    // 题解： 可以使用visited 或者 直接使用memory代替 visited
    // 矩阵中最长递增路径长度
    int[][] memory;
    int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

    public int longestIncreasingPath(int[][] matrix) {
        m = matrix.length;
        n = matrix[0].length;
        memory = new int[m][n];
        visited = new boolean[m][n];

        int result = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                result = Math.max(result, dfs(matrix, i, j));
            }
        }
        return result;
    }

    private int dfs(int[][] matrix, int i, int j) {
        if (memory[i][j] != 0) {
            return memory[i][j];
        }
        visited[i][j] = true;

        int result = 1;
        for (int[] dir : dirs) {
            int nextX = i + dir[0];
            int nextY = j + dir[1];
            if (nextX >= 0 && nextX < m && nextY >= 0 && nextY < n && !visited[nextX][nextY] && matrix[nextX][nextY] > matrix[i][j]) {
                result = Math.max(dfs(matrix, nextX, nextY) + 1, result);
            }
        }
        visited[i][j] = false;
        memory[i][j] = result;
        return result;
    }


    // 二叉树转排序的双向链表
    public TreeNode treeToDoublyList(TreeNode root) {
        TreeNode cur = root;
        Stack<TreeNode> stack = new Stack<>();
        TreeNode head = null;
        TreeNode prev = null;

        while (!stack.isEmpty() || cur != null) {
            while (cur != null) {
                stack.push(cur);
                cur = cur.left;
            }

            TreeNode pop = stack.pop();
            if (head == null) {
                head = pop;
                prev = pop;
            } else {
                prev.right = pop;
                pop.left = prev;

                prev = pop;
            }
            cur = pop.right;
        }

        head.left = prev;
        prev.right = head;
        return head;
    }

//    public int reverse(int x) {
//        long num = x;
//        long result = 0;
//        while (num != 0) {
//            result = result * 10 + num % 10;
//            num = num / 10;
//        }
//
//        if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
//            return 0;
//        }
//        return (int) result;
//    }


    // 删除二叉树搜索树的节点
    public TreeNode deleteNode(TreeNode root, int key) {
        // 1. 找到节点
        if (root == null) {
            return null;
        }

        if (root.val < key) {
            root.left = deleteNode(root.left, key);
        } else if (root.val > key) {
            root.right = deleteNode(root.right, key);
        } else {
            if (root.left == null && root.right == null) {
                return null;
            }
            if (root.left == null) {
                return root.right;
            }
            if (root.right == null) {
                return root.left;
            }

            TreeNode min = findMinNode(root.right);
            root.val = min.val;
            root.right = deleteNode(root.right, min.val);
        }
        return root;
    }

    private TreeNode findMinNode(TreeNode node) {
        TreeNode cur = node;
        while (cur.left != null) {
            cur = cur.left;
        }
        return cur;
    }


    // 贪心思路
    //维护两个变量：
    //
    //low：当前可能未匹配的左括号的最小数量（* 当作右括号时）
    //
    //high：当前可能未匹配的左括号的最大数量（* 当作左括号时）
    //
    //遍历每个字符：
    //
    //遇到 (：low++, high++
    //
    //遇到 )：low--, high--
    //
    //遇到 *：low--（当作右括号），high++（当作左括号）
    //
    //同时保证 low 不小于 0，如果 high < 0 直接返回 false。
    //
    //最后如果 low == 0 则有效。
    public boolean checkValidString(String s) {
        int low = 0;   // 可能的最小未匹配左括号数
        int high = 0;  // 可能的最大未匹配左括号数

        for (char c : s.toCharArray()) {
            if (c == '(') {
                low++;
                high++;
            } else if (c == ')') {
                low--;
                high--;
            } else { // '*'
                low--;    // 当作右括号
                high++;   // 当作左括号
            }

            // 如果 high < 0，说明右括号太多，无法匹配
            if (high < 0) return false;

            // low 不能为负，因为 * 可以当作空字符串，所以 low 至少为 0
            if (low < 0) low = 0;
        }

        // 最后最小未匹配左括号数为 0 才有效
        return low == 0;
    }


    // 圆环上有10个点，编号为0~9。从0点出发，每次可以逆时针和顺时针走一步，问走n步回到0点共有多少种走法。
    // 动态规划
    // 思路分析
    //圆环上有 10 个点（0~9），从 0 出发
    //每一步可以：
    //顺时针走一步：(i + 1) % 10
    //逆时针走一步：(i - 1 + 10) % 10
    //问走 恰好 n 步 回到 0 的不同走法总数
    public int huihuanSolution(int n) {
        int m = 10;
        // dp[step][pos]
        int[][] dp = new int[n + 1][m];

        // 看地推公式 就是初始化第一行： 但是走 0 步到 第 1 - 9 其实都是 0 种方法 没有方法，所以都是 0 了
        dp[0][0] = 1;

        for (int step = 1; step <= n; step++) {
            for (int pos = 0; pos < m; pos++) {
                // 从 pos-1 顺时针过来，或从 pos+1 逆时针过来
                int prev1 = (pos - 1 + m) % m;
                int prev2 = (pos + 1) % m;
                dp[step][pos] = dp[step - 1][prev1] + dp[step - 1][prev2];
            }
        }

        return dp[n][0];
    }


    // 三角形的最小路径和
    public int minimumTotal(List<List<Integer>> triangle) {
        int len = triangle.size();
        int[][] result = new int[len][len];

        result[0][0] = triangle.get(0).get(0);
        for (int i = 1; i < len; i++) {
            List<Integer> row = triangle.get(i);
            for (int k = 0; k <= i; k++) {
                if (k == 0) {
                    result[i][k] = result[i - 1][k] + row.get(k);
                } else if (k == i) {
                    result[i][k] = result[i - 1][k - 1] + row.get(k);
                } else {
                    result[i][k] = Math.min(result[i - 1][k], result[i - 1][k - 1]) + row.get(k);
                }
            }
        }
        int min = Integer.MAX_VALUE;
        for (int num : result[len - 1]) {
            min = Math.min(num, min);
        }
        return min;
    }


    // 二叉搜索树中第k小的元素
    int index = 0;

    public int kthSmallest(TreeNode root, int k) {
        Stack<TreeNode> stack = new Stack<>();
        TreeNode cur = root;
        TreeNode pop = null;

        while (!stack.isEmpty() || cur != null) {
            while (cur != null) {
                stack.push(cur);
                cur = cur.left;
            }

            pop = stack.pop();
            index++;
            if (index == k) {
                return pop.val;
            }

            cur = pop.right;
        }
        if (pop != null) {
            return pop.val;
        }
        return -1;
    }

    // 找数组中第k小的数字：


    public static void main(String[] args) {
        // 加一个0在开头，让索引对应长度
        // 长度:        0  1  2  3  4   5   6   7   8   9   10
//        int[] prices = {0, 1, 5, 8, 9, 10, 17, 17, 20, 24, 30};
//        System.out.println(cutRod(prices, 10));

        System.out.println(removeKdigits("1432219", 3));
    }
}
