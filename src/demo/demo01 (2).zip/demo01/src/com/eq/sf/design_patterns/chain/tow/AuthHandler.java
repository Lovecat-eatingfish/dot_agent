package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

// 权限校验处理器
public class AuthHandler extends Handler {
    @Override
    public boolean handle(Request request) {
        if (!request.hasPermission()) {
            System.out.println("权限校验失败，拦截请求");
            return false;
        }
        System.out.println("权限校验通过");
        return true;
    }
}
