package com.eq.sf.tree;

public class BinarySearchTree {

    // ============ 节点类 ============
    public static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        public TreeNode(int val) {
            this.val = val;
        }

        public TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val;
            this.left = left;
            this.right = right;
        }

    }


    private TreeNode root;

    public BinarySearchTree() {
    }

    public void insert(int value) {
        root = insert(root, value);
    }

    private TreeNode insert(TreeNode node, int value) {
        if (node == null) {
            return new TreeNode(value);
        }
        if (value < node.val) {
            node.left = insert(node.left, value);
        } else if (node.val < value) {
            node.right = insert(node.right, value);
        }
        return node;
    }

    public void remove(int val) {
        root = remove(root, val);
    }

    private TreeNode remove(TreeNode node, int val) {
        if (node == null) {
            return null;
        }
        if (val < node.val) {
            node.left = remove(node.left, val);
        } else if (val > node.val) {
            node.right = remove(node.right, val);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }

            TreeNode min = getMin(node.right);
            node.val = min.val;

            node.right = remove(node.right, min.val);
        }
        return node;
    }

    public TreeNode search(int val) {
        return search(root, val);
    }

    public TreeNode search(TreeNode node, int val) {
        if (node == null) {
            return null;
        }
        if (val < node.val) {
            return search(node.left, val);
        } else if (node.val < val) {
            return search(node.right, val);
        } else {
            return node;
        }
    }

    private TreeNode getMin(TreeNode node) {
        TreeNode cur = node;
        while (cur.left != null) {
            cur = cur.left;
        }
        return cur;
    }
}
