package com.eq.sf.stack;

import java.util.Iterator;

public class ArrayStack<E> implements Stack<E>, Iterable<E> {
    public E[] arr;
    public int size;
    public int capacity;
    int top;

    public ArrayStack(int capacity) {
        this.capacity = capacity;
        this.arr = (E[]) new Object[capacity];
        this.size = 0;
        this.top = 0;
    }

    @Override
    public boolean push(E value) {
        if (isFull()) {
            return false;
        }
        arr[top] = value;
        top++;
        size++;
        return true;
    }

    @Override
    public E pop() {
        if (isEmpty()) {
            return null;
        }
        top--;
        E pop = arr[top];
        size--;
        return pop;
    }

    @Override
    public E peek() {
        if (isEmpty()) {
            return null;
        }
        return arr[top - 1];
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean isFull() {
        return size == capacity;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int p = top;

            @Override
            public boolean hasNext() {
                return p > 0;
            }

            @Override
            public E next() {
                return arr[--p];
            }
        };
    }
}
