package com.eq.sf.solution;

import java.util.*;

public class AgainSolution {


    Map<Character, Integer> map = new HashMap<>();

    // 基本计算器
    public int calculate1(String s) {
        map.put('+', 1);
        map.put('-', 1);
        map.put('*', 2);
        map.put('/', 2);

        Deque<Character> ops = new ArrayDeque<>();
        Deque<Integer> nums = new ArrayDeque<>();
        s = s.replace(" ", "");
        int len = s.length();
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '(') {
                ops.addLast(c);
            } else if (c == ')') {
                while (!ops.isEmpty()) {
                    char top = ops.peekLast();
                    if (top == '(') {
                        ops.pollLast();
                        break;
                    } else {
                        cale(nums, ops);
                    }
                }
            } else {
                if (Character.isDigit(c)) {
                    int num = 0;
                    int j = i;
                    while (j < len && Character.isDigit(c)) {
                        num = num * 10 + s.charAt(j) - '0';
                        j++;
                    }
                    nums.addLast(num);
                    i = j - 1;
                } else {
                    while (!ops.isEmpty() && ops.peekLast() != '(' && map.get(c) <= map.get(ops.peekLast())) {
                        cale(nums, ops);
                    }
                    ops.addLast(c);
                }
            }
        }

        while (!ops.isEmpty()) {
            cale(nums, ops);
        }
        return nums.pollLast();
    }

    private void cale(Deque<Integer> nums, Deque<Character> ops) {
        if (nums.size() < 2 || ops.isEmpty()) return;

        int b = nums.pollLast();
        int a = nums.pollLast();
        char op = ops.pollLast();
        int res = 0;

        switch (op) {
            case '+':
                res = a + b;
                break;
            case '-':
                res = a - b;
                break;
            case '*':
                res = a * b;
                break;
            case '/':
                res = a / b;
                break;
            case '^':
                res = (int) Math.pow(a, b);
                break;
        }
        nums.addLast(res);
    }


    // 核心思路
    //建立大顶堆（父节点 ≥ 子节点）
    //
    //每次把堆顶（最大值）放到末尾
    //
    //剩余元素重新调整为大顶堆
    //
    //重复直到全部有序
    public void heapSort(int[] arr) {
        buildHeap(arr);

        for (int i = arr.length - 1; i > 0; i--) {
            swap(arr, 0, i);
            down(arr, i, 0);
        }
    }

    private void buildHeap(int[] arr) {
        for (int i = (arr.length - 1) / 2; i >= 0; i--) {
            down(arr, arr.length, i);
        }
    }

    // 堆排序的 时候down 需要传递一个size 超过的就可以不用再排序了
    private void down(int[] arr, int size, int index) {
        int maxIndex = index;
        int left = index * 2 + 1;
        int right = index * 2 + 2;
        if (left < size && arr[left] > arr[maxIndex]) {
            maxIndex = left;
        }
        if (right < size && arr[right] > arr[maxIndex]) {
            maxIndex = right;
        }

        if (maxIndex != index) {
            swap(arr, maxIndex, index);
            down(arr, size, maxIndex);
        }
    }

    private void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }


    // swap 迭代的实现
    private void down1(int[] arr, int index) {
        while (true) {
            int maxIndex = index;
            int left = index * 2 + 1;
            int right = index * 2 + 2;
            if (left < arr.length && arr[left] > arr[maxIndex]) {
                maxIndex = left;
            }
            if (right < arr.length && arr[right] > arr[maxIndex]) {
                maxIndex = right;
            }

            if (maxIndex == index) {
                break;
            }
            swap(arr, maxIndex, index);
            index = maxIndex;
        }
    }


    // 有重复元素的全排类问题， 返回不能有重复的排列
    // 给定一个可包含重复数字的序列 nums ，按任意顺序 返回所有不重复的全排列。
    List<List<Integer>> result2 = new ArrayList<>();
    LinkedList<Integer> path2 = new LinkedList<>();
    boolean[] used;

    public List<List<Integer>> permuteUnique(int[] nums) {
        used = new boolean[nums.length];
        Arrays.sort(nums);
        backtracking(nums);
        return result2;
    }

    private void backtracking(int[] nums) {
        if (path2.size() == nums.length) {
            result2.add(new ArrayList<>(path2));
            return;
        }

        for (int i = 0; i < nums.length; i++) {
            if (i > 0 && nums[i] == nums[i - 1] && !used[i - 1]) {
                continue;
            }
            if (used[i]) {
                continue;
            }

            path2.add(nums[i]);
            used[i] = true;

            backtracking(nums);

            path2.removeLast();
            used[i] = false;
        }
    }

    Map<Character, Integer> priority = new HashMap<>();

    public int calculate(String s) {
        priority.put('+', 1);
        priority.put('-', 1);
        priority.put('*', 2);
        priority.put('/', 2);
        s = s.replace(" ", "");
        int len = s.length();
        Stack<Character> ops = new Stack<>();
        Stack<Integer> nums = new Stack<>();

        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if (c == '(') {
                ops.push(c);
            } else if (c == ')') {
                while (!ops.isEmpty()) {
                    char op = ops.peek();
                    if (op == '(') {
                        ops.pop();
                        break;
                    }
                    calc(ops, nums);
                }
            } else if (Character.isDigit(c)) {
                int num = 0;
                int j = i;
                while (j < len && Character.isDigit(s.charAt(j))) {
                    num = num * 10 + s.charAt(j) - '0';
                    j++;
                }
                i = j - 1;
                nums.push(num);
            } else {
                // ✅ 关键修复：遇到 '(' 或栈为空时停止, ( 留给 ） 来处理就好了
                while (!ops.isEmpty() && ops.peek() != '('
                        && priority.get(c) <= priority.get(ops.peek())) {
                    calc(ops, nums);
                }
                ops.push(c);
            }
        }

        while (!ops.isEmpty()) {
            calc(ops, nums);
        }
        return nums.pop();
    }

    private void calc(Stack<Character> ops, Stack<Integer> nums) {
        int b = nums.pop();
        int a = nums.pop();
        char op = ops.pop();

        int result = 0;
        if (op == '+') {
            result = a + b;
        } else if (op == '-') {
            result = a - b;
        } else if (op == '*') {
            result = a * b;
        } else if (op == '/') {
            result = a / b;
        }
        nums.push(result);
    }


    // 移除掉 k 个数字 让 这个数字变得尽可能小
    public static String removeKdigits(String num, int k) {
        int len = num.length();
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < len; i++) {
            while (!stack.isEmpty() && k > 0 && stack.peek() > num.charAt(i)) {
                stack.pop();
                k--;
            }
            stack.push(num.charAt(i));
        }

        while (k > 0) {
            stack.pop();
            k--;
        }

        StringBuilder result = new StringBuilder();
        for (char c : stack) {
            if (c == '0' && result.length() == 0) {
                continue;
            }
            result.append(c);
        }

        return result.toString();
    }


    // 主函数：判断 B 是否是 A 的子结构
    public boolean isSubStructure(TreeNode A, TreeNode B) {
        // 根据题意，空树不是任何树的子结构
        if (A == null || B == null) {
            return false;
        }
        // 逻辑：以当前 A 节点为根匹配 || B 是 A 左子树的子结构 || B 是 A 右子树的子结构
        return recur(A, B) || isSubStructure(A.left, B) || isSubStructure(A.right, B);
    }

    // 辅助函数：判断从 A 的当前节点开始，是否包含 B 的结构
    boolean recur(TreeNode A, TreeNode B) {
        // 终止条件 1: B 遍历完了，说明 B 的所有节点都匹配上了
        if (B == null) {
            return true;
        }
        // 终止条件 2: A 遍历完了 或 当前节点值不相等
        if (A == null || A.val != B.val) {
            return false;
        }
        // 递归判断：当前节点值相等，继续判断左右子树是否也匹配
        return recur(A.left, B.left) && recur(A.right, B.right);
    }


    public double myPow(double x, int n) {
        if (n < 0) {
            x = 1 / x;
            n = -n;
        }
        double result = 1.0;
        double base = x;
        while (n > 0) {
            if (n % 2 == 1) {
                result *= base;
            }
            base *= base;
            n >>= 1;
        }
        return result;
    }

}
