package com.eq.sf.juc.solution;

public class GracefulShutdownService {
    private Thread worker;
    private volatile boolean running = true;

    public void start() {
        worker = new Thread(() -> {
            while (running && !Thread.currentThread().isInterrupted()) {
                try {
                    System.out.println("执行任务");
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            System.out.println("线程已停止");
            ;
        });
        worker.start();
    }

    public void shutdown() {
        System.out.println("收到停止信号，开始优雅关闭...");
        running = false;          // 让循环退出

        if (worker != null) {
            worker.interrupt();   // 唤醒 sleep/wait 阻塞
        }
        System.out.println("服务已停止");
    }

    public static void main(String[] args) throws InterruptedException {
        GracefulShutdownService service = new GracefulShutdownService();
        service.start();
        Thread.sleep(5000);
        service.shutdown();
    }
}
