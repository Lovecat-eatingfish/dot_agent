package com.eq.sf.tree;

/**
 * 新建叶子节点 height 必须初始化为 1，不能是 0
 * 节点旋转需要更新height
 */
public class AVLTree {

    // ============ 节点类 ============
    public static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        int height;

        public TreeNode(int val) {
            this.val = val;
            this.height = 1;
        }

        public TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val;
            this.left = left;
            this.right = right;
            this.height = 1;
        }

    }

    private TreeNode root;

    public void insert(int value) {
        root = insert(root, value);
    }

    private TreeNode insert(TreeNode node, int value) {
        if (node == null) {
            return new TreeNode(value);
        }
        if (value < node.val) {
            node.left = insert(node.left, value);
        } else if (node.val < value) {
            node.right = insert(node.right, value);
        }
        updateHeight(node);
        return balance(node);
    }

    public void remove(int value) {
        root = remove(root, value);
    }

    public TreeNode search(int val) {
        return search(root, val);
    }

    public TreeNode search(TreeNode node, int val) {
        if (node == null) {
            return null;
        }
        if (val < node.val) {
            return search(node.left, val);
        } else if (node.val < val) {
            return search(node.right, val);
        } else {
            return node;
        }
    }

    private TreeNode remove(TreeNode node, int value) {
        if (node == null) {
            return null;
        }
        if (value < node.val) {
            node.left = remove(node.left, value);
        } else if (node.val < value) {
            node.right = remove(node.right, value);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }

            TreeNode min = getMin(node.right);
            node.val = min.val;

            node.right = remove(node.right, min.val);
        }

        updateHeight(node);
        return balance(node);
    }

    private TreeNode getMin(TreeNode node) {
        TreeNode cur = node;
        while (cur.left != null) {
            cur = cur.left;
        }
        return cur;
    }

    private void updateHeight(TreeNode node) {
        node.height = Math.max(getHeight(node.left), getHeight(node.right)) + 1;
    }

    private int getBalance(TreeNode node) {
        return node == null ? 0 : getHeight(node.left) - getHeight(node.right);
    }

    private int getHeight(TreeNode node) {
        return node == null ? 0 : node.height;  // ✅ O(1)
    }

    private TreeNode leftRotate(TreeNode node) {
        TreeNode right = node.right;
        TreeNode son = right.left;

        right.left = node;
        node.right = son;

        updateHeight(node);
        updateHeight(right);

        return right;
    }

    private TreeNode rightRotate(TreeNode node) {
        TreeNode left = node.left;
        TreeNode son = left.right;


        left.right = node;
        node.left = son;

        updateHeight(node);
        updateHeight(left);
        return left;
    }

    private TreeNode leftRightRotate(TreeNode node) {
        node.left = leftRotate(node.left);
        return rightRotate(node);
    }

    private TreeNode rightLeftRotate(TreeNode node) {
        node.right = rightRotate(node.right);
        return leftRotate(node);
    }

    private TreeNode balance(TreeNode node) {
        if (node == null) {
            return null;
        }
        int balance = getBalance(node);
        // LL
        if (balance > 1 && getBalance(node.left) >= 0) {
            node = rightRotate(node);
        } else if (balance > 1 && getBalance(node.left) < 0) {
            // LR
            node = leftRightRotate(node);
        } else if (balance < -1 && getBalance(node.right) <= 0) {
            // RR
            node = leftRotate(node);
        } else if (balance < -1 && getBalance(node.right) > 0) {
            // RL
            node = rightLeftRotate(node);
        }
        return node;
    }


}
