package com.eq.sf.queue;

import java.util.Iterator;

public class ArrayCycleQueue3<E> implements Queue<E>, Iterable<E> {
    public  int capacity;
    public  E[] arr;
    public  int tail = 0;
    public  int head = 0;

    public ArrayCycleQueue3(int capacity) {
        this.capacity = capacity;
        this.arr = (E[]) new Object[capacity];
        tail = 0;
        head = 0;
    }

    @Override
    public boolean offer(E value) {
        if (isFull()) {
            System.out.println("队列已满");
            return false;
        }
        int index = tail % capacity;
        arr[index] = value;
        tail++;
        return true;
    }

    @Override
    public E poll() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        int index = head % capacity;
        E poll = arr[index];
        head++;
        return poll;
    }

    @Override
    public E peek() {
        if (isEmpty()) {
            System.out.println("对列是空");
            return null;
        }
        int index = head % capacity;
        return arr[index];
    }

    @Override
    public boolean isEmpty() {
        return tail == head;
    }

    @Override
    public boolean isFull() {
        return tail - head == capacity;
    }

    @Override
    public int size() {
        return tail - head;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int p = head;
            @Override
            public boolean hasNext() {
                return p < tail;
            }

            @Override
            public E next() {
                E value = arr[p % capacity];
                p++;
                return value;
            }
        };
    }
}
