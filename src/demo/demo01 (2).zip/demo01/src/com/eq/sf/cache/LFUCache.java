package com.eq.sf.cache;

import java.util.HashMap;
import java.util.Map;

// LFU（最不经常使用）：淘汰访问频率最低的数据。如果频率相同，淘汰最久未使用的（LRU策略）
public class LFUCache {


    // 节点定义
    class Node {
        int key;
        int value;
        int freq;  // 访问频率
        Node prev;
        Node next;

        Node(int key, int value) {
            this.key = key;
            this.value = value;
            this.freq = 1;
        }
    }

    // 双向链表（按访问时间排序，头部是最近访问）
    class DoublyLinkedList {
        Node head;
        Node tail;
        int size;

        public DoublyLinkedList() {
            this.head = new Node(-1, -1);
            this.tail = new Node(-1, -1);
            head.next = tail;
            tail.prev = head;
            size = 0;
        }

        public void addFirst(Node node) {
            node.next = head.next;
            head.next.prev = node;
            node.prev = head;
            head.next = node;
            size++;
        }

        public void addLast(Node node) {
            node.next = tail;
            node.prev = tail.prev;
            tail.prev.next = node;
            tail.prev = node;
            size++;
        }

        // 删除指定节点
        public void remove(Node node) {
            node.prev.next = node.next;
            node.next.prev = node.prev;
            size--;
        }

        public Node removeLast() {
            if (size == 0) {
                return null;
            }
            Node last = tail.prev;
            remove(last);
            return last;
        }

        boolean isEmpty() {
            return size == 0;
        }
    }

    private Map<Integer, Node> cache;
    private Map<Integer, DoublyLinkedList> freqMap;
    private int capacity;
    private int minFreq;

    public LFUCache(int capacity) {
        this.capacity = capacity;
        this.minFreq = 0;
        this.cache = new HashMap<>();
        this.freqMap = new HashMap<>();
    }

    public int get(int key) {
        Node node = cache.get(key);
        if (node == null) {
            return -1;
        }
        updateFreq(node);
        return node.value;
    }

    public void put(int key, int value) {
        if (capacity == 0) return;  // ✅ 添加边界检查

        Node node = cache.get(key);
        if (node != null) {
            node.value = value;
            updateFreq(node);
        } else {
            // 缓存已满，淘汰
            if (cache.size() == capacity) {
                DoublyLinkedList minFreqList = freqMap.get(minFreq);
                Node removeNode = minFreqList.removeLast();
                cache.remove(removeNode.key);

                if (minFreqList.isEmpty()) {
                    freqMap.remove(minFreq);
                    // 注意：淘汰后不需要更新minFreq，因为马上要插入新节点
                }
            }

            // 插入新节点
            Node newNode = new Node(key, value);
            newNode.freq = 1;
            cache.put(key, newNode);

            // ✅ 修复：正确添加到freqMap
            DoublyLinkedList list = freqMap.getOrDefault(1, new DoublyLinkedList());
            list.addFirst(newNode);
            freqMap.put(1, list);  // ✅ 关键修复！
            minFreq = 1;
        }
    }

    private void updateFreq(Node node) {
        int oldFreq = node.freq;
        DoublyLinkedList oldList = freqMap.get(oldFreq);
        oldList.remove(node);

        if (oldList.isEmpty()) {
            freqMap.remove(oldFreq);
            if (minFreq == oldFreq) {
                minFreq++;
            }
        }

        node.freq++;

        // ✅ 修复：正确添加到freqMap
        DoublyLinkedList newList = freqMap.getOrDefault(node.freq, new DoublyLinkedList());
        newList.addFirst(node);
        freqMap.put(node.freq, newList);  // ✅ 关键修复！
    }
}