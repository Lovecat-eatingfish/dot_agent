package com.eq.sf.juc.util;

import sun.misc.Unsafe;

public class CASUtil {

    private volatile int value = 0;

    private static final Unsafe UNSAFE = UnsafeUtil.getUnsafe();

    // value 在内存的偏移量地址
    private static final long VALUE_OFFSET;

    static {
        try {
            VALUE_OFFSET = UNSAFE.objectFieldOffset(
                    CASUtil.class.getDeclaredField("value")
            );
        }catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public boolean compareAndSet(int expect, int update) {
        return UNSAFE.compareAndSwapInt(this, VALUE_OFFSET, expect, update);
    }

    public int getValue() {
        return value;
    }
}
