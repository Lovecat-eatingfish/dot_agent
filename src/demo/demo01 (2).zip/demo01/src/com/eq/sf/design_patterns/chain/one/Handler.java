package com.eq.sf.design_patterns.chain.one;

public abstract class Handler {
    private Handler nextHandler;

    public void setNextHandler(Handler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public abstract void handle(Request request);


    public void doNext(Request request) {
        if (nextHandler != null) {
            nextHandler.handle(request);
        }
    }
}
