package com.eq.sf.graph;

import java.util.List;

public class Vertex {
    int val;
    boolean visited;
    Vertex prev;
    int status;

    int dist = Integer.MAX_VALUE;

    int indegree;

    List<Edge> edges;
}
