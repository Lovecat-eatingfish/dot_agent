# 并发
## ReentrantLock
### 条件变量
简单说：条件变量就是线程的“等待室”和“唤醒铃”。

Synchronized + wait / notify问题

问题： wait/notify 只有一个等待池，生产者、消费者都在里面。notifyAll() 会唤醒所有线程，但很多线程可能并不满足唤醒条件（比如唤醒的是生产者，但队列仍满），造成无效唤醒和性能浪费。
```java
synchronized(lock) {
    while (队列已满) {
        lock.wait();  // 所有线程都在同一个等待池
    }
    // 生产
    lock.notifyAll(); // 唤醒所有等待线程
}
```

Condition 允许你创建多个独立的等待队列（等待池），每个队列对应不同的条件。

```java
ReentrantLock lock = new ReentrantLock();
Condition notFull = lock.newCondition();   // 队列未满 → 生产者等待
Condition notEmpty = lock.newCondition();  // 队列非空 → 消费者等待

// 生产者
lock.lock();
try {
    while (队列已满) {
        notFull.await();  // 生产者进入 "notFull" 等待室
    }
    // 生产数据...
    notEmpty.signal();   // 只唤醒 "notEmpty" 等待室的消费者
} finally {
    lock.unlock();
}

// 消费者
lock.lock();
try {
    while (队列为空) {
        notEmpty.await(); // 消费者进入 "notEmpty" 等待室
    }
    // 消费数据...
    notFull.signal();    // 只唤醒 "notFull" 等待室的生产者
} finally {
    lock.unlock();
}
```



### Condition对象
await() 不是简单等待，它会原子性地释放锁并挂起线程。

当被 signal() 唤醒后，线程会重新尝试获取锁，获取成功后才从 await() 返回继续执行。

必须用 while 循环检查条件，因为被唤醒后条件可能又被其他线程改变了。



```text
                    ┌─────────────────────────────┐
                    │       ReentrantLock         │
                    │         (一把锁)             │
                    └─────────────┬───────────────┘
                                  │
                    ┌─────────────┴───────────────┐
                    │     lock.newCondition()     │
                    │     创建了一个"池子"         │
                    └─────────────┬───────────────┘
                                  │
                    ┌─────────────▼───────────────┐
                    │   条件变量的等待队列（池子）   │
                    │  ┌─────┐ ┌─────┐ ┌─────┐   │
                    │  │线程A│ │线程B│ │线程C│   │  ← 调用 await() 的线程都在这里
                    │  └─────┘ └─────┘ └─────┘   │
                    └─────────────────────────────┘
```


### 使用
条件变量是：条件不满足时等待，条件满足时继续执行。


```java
while(没空位){  // 条件不满足

等待();       // 阻塞，直到被叫号
}

吃饭();          // 条件满足，继续执行
```





# 比较器

## Compareable 内部比较器

让类本身实现 Comparable<T> 接口，重写 compareTo(T o) 方法。


```java
public class Student implements Comparable<Student> {
    private String name;
    private int score;
    
    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }
    
    // 重写 compareTo：按分数升序排列
    @Override
    public int compareTo(Student o) {
        return this.score - o.score;  // 升序
        // return o.score - this.score; // 降序
    }
    
    // getter、toString 省略...
}
```


compareTo 返回值含义
返回值	含义


负数	this < o（当前对象排在前面）


0	相等
正数	this > o（当前对象排在后面）


口诀：this - o = 升序，o - this = 降序






## Comparator（外部比较器）


1. 什么时候用？
- 类的源码改不了（比如 String、Integer 这种）

- 想按多种规则排序（按分数、按姓名、按年龄...）

- 不想修改类本身


实现 Comparator<T> 接口，重写 compare(T o1, T o2) 方法。


3. 三种使用方式
   方式一：单独写一个比较器类
```java
   java
   // 按分数降序的比较器
   class ScoreDescComparator implements Comparator<Student> {
   @Override
   public int compare(Student o1, Student o2) {
   return o2.getScore() - o1.getScore();  // 降序
   }
   }
```

// 使用
Arrays.sort(students, new ScoreDescComparator());
方式二：匿名内部类（老写法）
```java
java
Arrays.sort(students, new Comparator<Student>() {
@Override
public int compare(Student o1, Student o2) {
return o1.getScore() - o2.getScore();
}
});
```
方式三：Lambda 表达式（最常用，Java 8+）⭐
```java
java
// 按分数升序
Arrays.sort(students, (o1, o2) -> o1.getScore() - o2.getScore());

// 按分数降序
Arrays.sort(students, (o1, o2) -> o2.getScore() - o1.getScore());

// 按姓名排序（字符串用 compareTo）
Arrays.sort(students, (o1, o2) -> o1.getName().compareTo(o2.getName()));


```


# 算法
## 动态规划

### 背包问题推导式
```java
public int completeKnapsack2D(int[] weights, int[] values, int capacity) {
    int n = weights.length;
    int[][] dp = new int[n + 1][capacity + 1];
    
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= capacity; j++) {
            // 不选第 i 件
            dp[i][j] = dp[i - 1][j];
            
            // 选第 i 件（可以选多件）
            if (j >= weights[i - 1]) {
                // ✅ 注意是 dp[i][...] 而不是 dp[i-1][...]
                dp[i][j] = Math.max(dp[i][j], 
                                   dp[i][j - weights[i - 1]] + values[i - 1]);
            }
        }
    }
    return dp[n][capacity];
}
```