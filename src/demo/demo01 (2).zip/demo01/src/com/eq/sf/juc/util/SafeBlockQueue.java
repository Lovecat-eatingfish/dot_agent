package com.eq.sf.juc.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

// ✅ 双锁分离（高并发性能）
//
//✅ 条件变量精确控制
//
//✅ 链式唤醒（避免生产者/消费者饥饿）
//
//✅ 锁外唤醒（避免死锁）
//
//✅ 循环数组（空间复用）
//
//✅ 完整的边界处理
public class SafeBlockQueue {
    private AtomicInteger size;
    private int capacity;
    private int tail;
    private int head;
    int[] arr;
    private ReentrantLock headLock;
    private ReentrantLock tailLock;
    private Condition headCon;
    private Condition tailCon;

    public SafeBlockQueue(int capacity) {
        this.size = new AtomicInteger(0);
        this.capacity = capacity;
        arr = new int[capacity];
        this.tail = 0;
        this.head = 0;
        headLock = new ReentrantLock();
        tailLock = new ReentrantLock();
        headCon = headLock.newCondition();
        tailCon = tailLock.newCondition();
    }

    public void push(int value) throws InterruptedException {
        int c = -1;
        tailLock.lock();
        try {
            while (isFull()) {
                tailCon.await();
            }

            arr[tail] = value;
            tail = (tail + 1) % capacity;
            c = size.getAndIncrement();
            // 删除之后 还没有满 继续通知生产者
            if (c + 1 < capacity) {
                tailCon.signal();
            }
        } finally {
            tailLock.unlock();
        }

        // 生产之前是空的， 生产之后通知消费者， 消费数据
        if (c == 0) {
            headLock.lock();
            try {
                headCon.signal();
            } finally {
                headLock.unlock();
            }
        }
    }

    public int take() throws InterruptedException {
        int c = -1;
        int take = -1;
        headLock.lock();
        try {
            while (isEmpty()) {
                headCon.await();
            }

            take = arr[head];
            head = (head + 1) % capacity;
            c = size.getAndDecrement();
            // 如果 还存在空间 继续消费者消费
            if (c > 1) {
                headCon.signal();
            }

        } finally {
            headLock.unlock();
        }

        // 消费之前 是满的， 消费之后需要通知生产者继续生产
        if (c == capacity) {
            tailLock.lock();
            try {
                tailCon.signal();
            } finally {
                tailLock.unlock();
            }
        }
        return take;
    }

    public boolean isEmpty() {
        return size.get() == 0;
    }

    public boolean isFull() {
        return size.get() == capacity;
    }
}
