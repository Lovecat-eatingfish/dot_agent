package com.eq.sf.juc.util;

import sun.misc.Unsafe;

public class CASSpinLock {
    private volatile int state = 0;
    
    private static final Unsafe UNSAFE = UnsafeUtil.getUnsafe();
    private static final long STATE_OFFSET;
    
    static {
        try {
            STATE_OFFSET = UNSAFE.objectFieldOffset(
                CASSpinLock.class.getDeclaredField("state")
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public void lock() {
        int spin = 0;
        while (!UNSAFE.compareAndSwapInt(this, STATE_OFFSET, 0, 1)) {
            if (spin < 20) {
                spin++;
                // 短自旋（空转）
            } else {
                Thread.yield();  // ✅ Java 8 兼容
                spin = 0;
            }
        }
    }
    
    public void unlock() {
        state = 0;
    }
}