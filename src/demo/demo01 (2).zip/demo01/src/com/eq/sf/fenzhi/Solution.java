package com.eq.sf.fenzhi;

import java.util.Random;

public class Solution {
    /**
     * 在数组中找到第k小的元素（k从0开始）
     *
     * @param nums 原始数组
     * @param k    第k小（0表示最小值）
     * @return 第k小的元素值
     */
    public static int quickSelect(int[] nums, int k) {
        return quickSelectHelper(nums, 0, nums.length - 1, k);
    }

    // 递归fun定义： 从nums 的left 到 right中找 到第k小的元素 返回他的值
    private static int quickSelectHelper(int[] nums, int left, int right, int k) {
        if (left == right) {
            return nums[left];
        }
        Random random = new Random();
        int randomIndex = random.nextInt(right - left + 1);
        swap(nums, left, randomIndex);

        int partition = partition(nums, left, right);
        if (k == partition) {
            return nums[partition];
        } else if (k < partition) {
            return quickSelectHelper(nums, left, partition - 1, k);
        } else {
            return quickSelectHelper(nums, partition + 1, right, k);
        }
    }

    private static int partition(int[] arr, int left, int right) {
        int i = left;
        int j = right;
        int temp = arr[left];
        while (i < j) {
            while (i < j && arr[j] >= temp) {
                j--;
            }
            while (i < j && arr[i] <= temp) {
                i++;
            }

            if (i < j) {
                swap(arr, i, j);
            }
        }
        swap(arr, left, i);
        return i;
    }

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }


    // 找到第K 大的元素 == > 第k大 = 第(n-k)小
    public static int findKthLargest(int[] nums, int k) {
        return quickSelectHelper(nums, 0, nums.length - 1, nums.length - k);
    }


    // 快速排序
    public static void quickSort(int[] nums) {
        quickSortArr(nums, 0, nums.length - 1);
    }

    private static void quickSortArr(int[] nums, int left, int right) {
        if (left == right) {
            return;
        }
        int position = partition(nums, left, right);
        quickSortArr(nums, left, position - 1);
        quickSortArr(nums, position + 1, right);
    }


    // 快速排序和快速选择的区别：
    // // 快速排序：递归处理两侧
    //quickSort(arr, left, pivot - 1);
    //quickSort(arr, pivot + 1, right);
    //
    // 快速选择：只递归一侧
    //if (k < pivotIndex) {
    //    quickSelectHelper(arr, left, pivotIndex - 1, k);
    //} else if (k > pivotIndex) {
    //    quickSelectHelper(arr, pivotIndex + 1, right, k);
    //}

}
