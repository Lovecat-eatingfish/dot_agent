package com.eq.sf.design_patterns.chain.tow;

import com.eq.sf.design_patterns.chain.one.Request;

import java.util.ArrayList;
import java.util.List;

public class HandlerChain {
    private List<Handler> handlerList = new ArrayList<>();


    public void addHandler(Handler handler) {
        handlerList.add(handler);
    }

    public void removeHandler(Handler handler) {
        handlerList.remove(handler);
    }

    public void handle(Request request) {
        for (Handler handler : handlerList) {
            boolean continueProcess = handler.handle(request);
            if (!continueProcess) {
                break;
            }
        }
    }
}
